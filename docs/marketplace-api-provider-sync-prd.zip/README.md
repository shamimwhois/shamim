# API & Provider Sync PRD package

Files:
- `08-api-provider-sync-master-prd.md` — seller credentials, REST endpoints, prefixed public IDs, provider adapters, custom parameters, price rules, folders/files, automation and site-to-site sync.
- `openapi-v1-starter.json` — starter OpenAPI contract to expand before implementation.

Important:
- `{BRAND_PREFIX}-{XXXX}-{XXXX}-{XXXX}-{XXXX}` is a readable public reference format, not a standard UUID and not an API secret. Keep a canonical UUID internally.
- Site-to-site synchronization must be directional per entity/field; bidirectional sync requires conflict detection and loop prevention.
- Provider integration must use authorized APIs and documented terms.
- Remote URL fetches require SSRF protections.
