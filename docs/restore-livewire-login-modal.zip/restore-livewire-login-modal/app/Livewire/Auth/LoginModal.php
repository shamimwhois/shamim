<?php

namespace App\Livewire\Auth;

use Illuminate\Auth\Events\Failed;
use Illuminate\Auth\Events\Lockout;
use Illuminate\Auth\Events\Login;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\On;
use Livewire\Component;

class LoginModal extends Component
{
    public bool $isOpen = false;
    public string $email = '';
    public string $password = '';
    public bool $remember = true;
    public bool $showPassword = false;

    #[On('open-login-modal')]
    public function open(): void
    {
        $this->resetValidation();
        $this->isOpen = true;
    }

    public function close(): void
    {
        $this->isOpen = false;
        $this->reset(['email', 'password', 'showPassword']);
        $this->remember = true;
        $this->resetValidation();
    }

    public function togglePasswordVisibility(): void
    {
        $this->showPassword = ! $this->showPassword;
    }

    public function login()
    {
        $validated = $this->validate([
            'email' => ['required', 'string', 'email:rfc', 'max:254'],
            'password' => ['required', 'string', 'max:1024'],
            'remember' => ['boolean'],
        ]);

        $throttleKey = Str::transliterate(
            Str::lower($validated['email']).'|'.request()->ip()
        );

        if (RateLimiter::tooManyAttempts($throttleKey, 5)) {
            event(new Lockout(request()));

            $seconds = RateLimiter::availableIn($throttleKey);

            throw ValidationException::withMessages([
                'email' => "Too many login attempts. Try again in {$seconds} seconds.",
            ]);
        }

        $credentials = [
            'email' => $validated['email'],
            'password' => $validated['password'],
        ];

        if (! Auth::guard()->attempt($credentials, (bool) $validated['remember'])) {
            RateLimiter::hit($throttleKey, 60);

            event(new Failed(Auth::guard()->getName(), null, $credentials));

            throw ValidationException::withMessages([
                'email' => 'These credentials do not match our records.',
            ]);
        }

        RateLimiter::clear($throttleKey);

        $user = Auth::user();

        // Regenerate the session ID after authentication to prevent session fixation.
        request()->session()->regenerate();

        event(new Login(Auth::guard()->getName(), $user, (bool) $validated['remember']));

        $this->reset(['password', 'showPassword']);
        $this->isOpen = false;

        $this->dispatch('auth:login-succeeded');

        // Respect Laravel's intended URL, falling back to the named account route.
        return redirect()->intended(route('account.dashboard', absolute: false));
    }

    public function render()
    {
        return view('livewire.auth.login-modal');
    }
}
