# Restore custom Livewire login modal

This is a starting implementation for Laravel 13 + Livewire 4 + Fortify.

## Files

- `app/Livewire/Auth/LoginModal.php`
- `resources/views/livewire/auth/login-modal.blade.php`

Copy the files into the corresponding paths in your Laravel application.

## Register the component

In your app layout, where the global modal host should be available:

```blade
<livewire:auth.login-modal />
```

Open it from any Blade/Livewire view:

```blade
<button type="button" wire:click="$dispatch('open-login-modal')">
    Login
</button>
```

From Alpine or plain JavaScript, dispatch the Livewire event through your application's chosen bridge. Do not assume browser events and Livewire events are interchangeable without wiring them.

## Requirements and notes

1. Install and configure Fortify. This component uses Laravel's session guard `attempt()` and Laravel's rate limiter directly; it does **not** execute Fortify's HTTP login pipeline. It is compatible with a Fortify-backed application, but if you have custom Fortify login pipeline steps (for example, custom 2FA or organization checks), move this logic into a shared authentication action or adapt the component to those steps before production.
2. Ensure `account.dashboard` exists, and that `password.request` exists. Change route names if your project uses different names.
3. Ensure the `users` table has an `email` column and your user provider is configured correctly.
4. Add `@livewireStyles` and `@livewireScripts` (or the equivalent required by your Livewire 4 layout) and compile Tailwind CSS.
5. This example uses email login. For username login, implement a deliberate identifier resolver and corresponding validation.
6. Production requires HTTPS, configured trusted proxies, secure session cookies, CSRF protection, dependency updates and tests.
7. Add feature tests for valid/invalid credentials, rate limiting, session regeneration, remember-me, redirect behavior and concurrent requests.
8. Review whether the `max:1024` password validation limit matches your app's password policy and database/auth provider configuration.

The UI is a custom presentation layer. It does not collect or authenticate credentials in a static preview.
