<div>
    @if ($isOpen)
        <div
            class="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-black/80 p-4 backdrop-blur-sm"
            x-data
            x-on:keydown.escape.window="$wire.close()"
            wire:key="restore-login-modal"
            role="presentation"
        >
            <button
                type="button"
                class="absolute inset-0 h-full w-full cursor-default"
                aria-label="Close login dialog"
                wire:click="close"
                tabindex="-1"
            ></button>

            <section
                class="relative z-10 w-full max-w-md overflow-hidden rounded-2xl border border-white/10 bg-[#0d141b] text-[#f2f6fa] shadow-2xl shadow-black/60"
                role="dialog"
                aria-modal="true"
                aria-labelledby="login-modal-title"
                x-init="$nextTick(() => $refs.email?.focus())"
            >
                <div class="h-1 w-full bg-gradient-to-r from-red-700 via-red-500 to-cyan-400"></div>

                <div class="flex items-start justify-between gap-4 border-b border-white/10 px-6 py-5">
                    <div>
                        <p class="mb-2 text-[10px] font-bold uppercase tracking-[0.28em] text-red-400">
                            Secure account access
                        </p>
                        <h2 id="login-modal-title" class="text-2xl font-black tracking-tight">
                            Welcome <span class="text-red-500">back.</span>
                        </h2>
                        <p class="mt-1 text-sm text-slate-400">Sign in to access your files and purchases.</p>
                    </div>

                    <button
                        type="button"
                        wire:click="close"
                        class="rounded-lg border border-white/10 p-2 text-slate-400 transition hover:border-red-500/50 hover:text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                        aria-label="Close dialog"
                    >
                        <svg viewBox="0 0 24 24" class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <path d="m6 6 12 12M18 6 6 18"/>
                        </svg>
                    </button>
                </div>

                <form wire:submit="login" class="space-y-5 px-6 py-6" novalidate>
                    <div>
                        <label for="login-email" class="mb-2 block text-sm font-semibold text-slate-200">
                            Email address
                        </label>
                        <input
                            id="login-email"
                            x-ref="email"
                            type="email"
                            wire:model="email"
                            autocomplete="username"
                            inputmode="email"
                            maxlength="254"
                            required
                            class="w-full rounded-xl border border-[#26313b] bg-[#080d12] px-4 py-3 text-sm outline-none transition placeholder:text-slate-600 focus:border-red-500 focus:ring-2 focus:ring-red-500/20"
                            placeholder="you@example.com"
                            @disabled($errors->has('email') && $errors->has('password'))
                        >
                        @error('email')
                            <p class="mt-2 text-sm text-red-400" role="alert">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <div class="mb-2 flex items-center justify-between gap-3">
                            <label for="login-password" class="block text-sm font-semibold text-slate-200">
                                Password
                            </label>
                            <a
                                href="{{ route('password.request') }}"
                                class="text-xs font-semibold text-slate-400 underline-offset-4 hover:text-red-400 hover:underline"
                            >
                                Forgot password?
                            </a>
                        </div>

                        <div class="relative">
                            <input
                                id="login-password"
                                type="{{ $showPassword ? 'text' : 'password' }}"
                                wire:model="password"
                                autocomplete="current-password"
                                required
                                class="w-full rounded-xl border border-[#26313b] bg-[#080d12] px-4 py-3 pr-16 text-sm outline-none transition placeholder:text-slate-600 focus:border-red-500 focus:ring-2 focus:ring-red-500/20"
                                placeholder="Enter your password"
                            >
                            <button
                                type="button"
                                wire:click="togglePasswordVisibility"
                                class="absolute inset-y-0 right-3 my-auto h-8 rounded-md px-2 text-xs font-semibold text-slate-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                                aria-label="{{ $showPassword ? 'Hide password' : 'Show password' }}"
                                aria-pressed="{{ $showPassword ? 'true' : 'false' }}"
                            >
                                {{ $showPassword ? 'Hide' : 'Show' }}
                            </button>
                        </div>
                        @error('password')
                            <p class="mt-2 text-sm text-red-400" role="alert">{{ $message }}</p>
                        @enderror
                    </div>

                    <label class="flex cursor-pointer items-center gap-3 text-sm text-slate-300">
                        <input
                            type="checkbox"
                            wire:model="remember"
                            class="h-4 w-4 rounded border-slate-600 bg-[#080d12] text-red-500 focus:ring-red-500"
                        >
                        Remember me on this device
                    </label>

                    <button
                        type="submit"
                        wire:loading.attr="disabled"
                        wire:target="login"
                        class="flex w-full items-center justify-center gap-2 rounded-xl bg-red-600 px-4 py-3.5 text-sm font-black uppercase tracking-wider text-white transition hover:bg-red-500 focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-offset-2 focus:ring-offset-[#0d141b] disabled:cursor-not-allowed disabled:opacity-60"
                    >
                        <svg wire:loading wire:target="login" class="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-opacity=".25" stroke-width="3"/>
                            <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
                        </svg>
                        <span wire:loading.remove wire:target="login">Sign in securely</span>
                        <span wire:loading wire:target="login">Verifying…</span>
                    </button>

                    <p class="text-center text-sm text-slate-400">
                        Don't have an account?
                        <button
                            type="button"
                            wire:click="$dispatch('open-register-modal')"
                            class="font-bold text-red-400 underline-offset-4 hover:underline"
                        >
                            Create account
                        </button>
                    </p>

                    <p class="text-center text-[11px] leading-5 text-slate-500">
                        Your credentials are sent to the application over HTTPS in production.
                        Never share your password or one-time codes.
                    </p>
                </form>
            </section>
        </div>
    @endif
</div>
