# PRD 02 --- Seller Panel

## Digital File Marketplace

**Version:** 1.0\
**Status:** Draft for implementation\
**Stack:** Laravel 13, PHP 8.5+, Livewire 4, Tailwind CSS 4

## 1. Purpose

The Seller Panel enables approved sellers to manage their profile,
digital products, file versions, pricing, orders, customer support,
sales analytics and payout requests. Seller data must be
tenant-isolated: a seller may access only their own listings, orders,
files, balances and reports unless an explicit permission allows
otherwise.

## 2. Goals

-   Provide a clear seller onboarding and approval process.
-   Let approved sellers create and maintain digital listings.
-   Securely manage digital file uploads and versions.
-   Show order, revenue, commission, refund and payout information
    transparently.
-   Prevent sellers from accessing another seller's data or private
    customer data beyond what is necessary to fulfill an order.

## 3. Seller lifecycle

Suggested states: `draft`, `submitted`, `under_review`,
`needs_information`, `approved`, `rejected`, `suspended`, `closed`.

Only approved and non-suspended sellers may publish products or receive
new sales. State transitions must be server-controlled and audited.

## 4. Functional requirements

### SEL-001 Onboarding

-   Seller applies with required profile/business details.
-   Validate required fields and accepted terms.
-   Upload verification documents only if required by marketplace
    policy.
-   Show application status and reviewer requests.
-   Allow resubmission after corrections.
-   Notify seller when status changes.
-   Store sensitive verification documents privately with restricted
    access and retention rules.

### SEL-002 Seller profile

-   Manage public display name, slug, logo/avatar, description, support
    contact and permitted public details.
-   Changes to sensitive legal/payment details may require review or
    re-verification.
-   Keep internal review notes and private verification data out of
    public profile responses.

### SEL-003 Product management

-   Create, edit, preview, submit, archive and duplicate listings where
    allowed.
-   Fields: title, slug, description, category, brand/device
    compatibility, price, currency, file metadata, version, release
    notes, preview images and status.
-   Validate price/currency, file requirements and taxonomy.
-   Require moderation before publication if marketplace policy enables
    it.
-   Preserve historical order-item snapshots when listing details
    change.
-   Prevent sellers from assigning another seller's product/file IDs.

### SEL-004 Digital file upload

-   Upload to private storage using a controlled server-side flow.
-   Enforce file size/type limits and validate MIME/signature where
    appropriate.
-   Generate checksum and metadata where feasible.
-   Scan uploads before publication if malware scanning is available.
-   Keep preview assets separate from paid originals.
-   Track upload, processing, scan and publication states.
-   Never expose raw storage paths or permanent public URLs for paid
    originals.

### SEL-005 Version management

-   Create a new version with version label, release notes and file.
-   Support rollback to a prior version only through an audited
    operation.
-   Do not silently overwrite the file tied to an historical order.
-   Follow the product's configured entitlement rule: purchased version,
    latest version or both.

### SEL-006 Seller orders

-   List only orders containing the seller's own items.
-   Show order status, line-item details, relevant fulfillment status
    and permitted customer information.
-   Do not expose payment secrets, full payment credentials or unrelated
    order items belonging to other sellers.
-   Handle digital fulfillment through the central entitlement/download
    system; sellers must not bypass it by sending public file links.
-   Allow support notes/messages only if messaging is in scope.

### SEL-007 Sales and analytics

-   Show gross sales, seller earnings, marketplace commission, refunds,
    fees, pending balance and paid payouts.
-   Define calculation rules, currency handling and reporting time zone.
-   Reconcile reports to ledger entries.
-   Avoid treating pending payments as earned revenue.
-   Provide date filters and CSV export only with authorization and safe
    escaping.

### SEL-008 Commission and ledger

-   Display the commission rule applicable to each order.
-   Record financial changes as ledger entries rather than only mutating
    a balance.
-   Account for refunds, chargebacks, fees, reserves and adjustments.
-   Changes to commission policy must not silently rewrite historical
    transactions.

### SEL-009 Payout requests

-   Show eligible balance and minimum payout requirements.
-   Collect payout details through protected forms and restrict access
    to staff who need them.
-   Validate payout method, currency, minimums and account ownership
    according to policy.
-   Prevent duplicate concurrent payout requests.
-   Show pending, approved, processing, paid, rejected and failed
    states.
-   A seller must not mark their own payout as paid.

### SEL-010 Notifications

-   Notify seller about application status, listing moderation, new
    relevant orders, refund/dispute status, payout status and security
    changes.
-   Use in-app and email notifications according to configuration.
-   Do not include private file URLs or sensitive payment data in
    notification content.

### SEL-011 Account security

-   Use central Fortify authentication.
-   Support password recovery, Google OAuth and optional passkeys/TOTP
    according to platform configuration.
-   Let sellers manage their own passkeys/2FA, sessions and tokens where
    enabled.
-   Require recent authentication for payout/payment-detail changes.

## 5. Permissions and tenant isolation

-   Seller ownership must be checked through policies and query scoping.
-   Never rely on a seller ID supplied by the browser without verifying
    ownership.
-   Test horizontal privilege escalation using IDs from other sellers.
-   Admin support access must be explicit and audited.
-   Suspended sellers cannot create/publish listings or request payouts
    except where a documented payout/appeal process allows it.

## 6. UI/UX requirements

-   Seller dashboard with actionable status cards.
-   Product wizard with save-draft and validation.
-   Upload progress, failure and retry feedback.
-   Listing status badges and moderation feedback.
-   Order and payout tables with filters.
-   Mobile-friendly navigation and accessible forms.
-   Clear distinction between gross sales, net earnings, commission and
    withdrawable balance.

## 7. Data requirements

Likely entities: seller_profiles, seller_applications, products,
product_files/file_versions, orders, order_items, seller_ledger_entries,
payout_requests, payouts, refunds, notifications and activity_log.

Every seller-owned record must have a clear ownership relationship. Use
database constraints and indexes for seller ID, status, slug and
date-based reporting.

## 8. Acceptance criteria

-   [ ] A new seller cannot publish until approved when approval is
    required.
-   [ ] A seller cannot read or mutate another seller's products, files,
    orders or payout records.
-   [ ] Uploads remain private until approved/published under policy.
-   [ ] File replacement preserves historical purchase references.
-   [ ] Earnings reconcile to ledger entries and payment/refund records.
-   [ ] Duplicate payout requests are prevented.
-   [ ] Sellers cannot mark their own payout as paid.
-   [ ] Suspension blocks prohibited seller actions.
-   [ ] Security-sensitive changes require re-authentication and are
    audited.
-   [ ] Pest tests cover ownership denial and state transitions.

## 9. Open decisions

-   Required seller verification level and documents.
-   Whether listing moderation is mandatory.
-   Commission percentage/fixed fees and effective-date policy.
-   Minimum payout, currencies, schedule, reserves and refund/chargeback
    handling.
-   Supported payout providers and eligibility.
-   Whether seller-to-customer messaging is included in MVP.

## 10. Definition of done

Seller workflows are permission-protected, financial figures reconcile,
files remain private, ownership tests pass and product/QA owners sign
off.
