# PRD 05 --- Payments, Orders, Refunds & Seller Settlements

## Digital File Marketplace

**Version:** 1.0\
**Status:** Draft for implementation\
**Stack:** Laravel 13, PHP 8.5+, MySQL 8.4+, queues as required

## 1. Purpose

The Payments module manages checkout sessions, payment attempts,
verified provider events, order financial states, refunds, seller
commissions, ledger entries and payouts. It is the financial source of
truth for the marketplace.

This module must not trust browser redirects or client-supplied payment
status. Financial transitions must be verified, auditable and
idempotent.

## 2. Product decisions and scope

MVP includes: - One-time digital product payments. - A payment-provider
contract and at least one selected provider. - Verified webhooks. -
Orders and payment attempts. - Entitlement creation after confirmed
payment. - Basic refunds if supported by the selected provider and
business policy.

Multi-currency, subscriptions, seller payouts, reserves, chargeback
automation and advanced reconciliation may be phased. If the product
launches as a multi-seller marketplace, seller ledger and payout design
must be included before enabling seller sales.

## 3. Payment lifecycle

Suggested flow:

`Customer checkout → Server creates pending order → Provider checkout session → Provider processes payment → Signed webhook received → Signature/event/amount/currency verified → Idempotent database transaction → Payment marked successful → Order marked paid → Entitlement created → Customer notified`

A browser return/redirect is only a user-experience signal. It is not
proof of payment.

## 4. Functional requirements

### PAY-001 Provider contract

Define a contract with operations equivalent to: - Create checkout
session. - Verify/normalize incoming webhook event. - Query payment
status when supported. - Initiate refund when supported. - Return
normalized results and provider references.

Keep provider-specific fields inside adapters. Business logic must
operate on normalized payment/order concepts.

### PAY-002 Provider selection

Before implementing a provider, verify: - Merchant eligibility and
onboarding requirements. - Supported country, settlement currency and
customer currencies. - Official API and webhook verification process. -
Refund support and transaction lookup capabilities. - Fees, settlement
schedule and operational limitations. - Current PHP/Laravel
compatibility of any SDK/package. - Sandbox availability and test
scenarios.

Do not assume Cashier is a universal payment gateway. Use Cashier only
for the billing/provider model it supports.

### PAY-003 Order creation and pricing

-   Calculate prices, discounts, fees and totals on the server.
-   Store amount in integer minor units or a clearly documented decimal
    strategy.
-   Store currency explicitly.
-   Snapshot product name, seller, SKU/identifier, price and version in
    order items.
-   Use an idempotency key or equivalent duplicate-submission control.
-   Revalidate product availability and price before checkout.
-   Define tax treatment separately; do not invent tax values.

### PAY-004 Checkout session

-   Create/reuse a valid pending order.
-   Send only necessary information to the provider.
-   Never expose provider secret keys to the browser.
-   Persist provider session/reference identifiers.
-   Handle cancelled, expired and failed checkout sessions.
-   Prevent repeated browser requests from creating unintended duplicate
    orders.

### PAY-005 Webhook verification

-   Verify the signature using the provider's documented algorithm.
-   Validate event identity, event type, amount, currency and associated
    order/payment.
-   Reject invalid signatures and malformed events.
-   Store a sanitized event record for audit/replay protection.
-   Do not log secrets, full payment credentials or sensitive payload
    fields.
-   Apply provider-specific replay/timestamp rules where available.

### PAY-006 Idempotent event processing

-   Uniquely identify provider events/transactions.
-   Repeated webhook delivery must not duplicate a payment, refund,
    ledger entry or entitlement.
-   Use database transactions and row locking/unique constraints as
    appropriate.
-   Process events safely if they arrive out of order.
-   A retry must be safe to execute more than once.

### PAY-007 Payment states

Use a documented state machine, for example: `created`, `pending`,
`requires_action`, `succeeded`, `failed`, `cancelled`,
`partially_refunded`, `refunded`, `disputed`.

Only valid transitions are allowed. Preserve provider event history
rather than overwriting all evidence with a single mutable status.

### PAY-008 Order state synchronization

Order state changes must be driven by verified payment/domain actions. A
successful verified payment may mark an eligible order as paid and
create an entitlement in a transaction. Failed/cancelled events must not
grant access.

### PAY-009 Entitlement issuance

-   Create entitlements only after the configured successful-payment
    condition.
-   Ensure uniqueness so repeated success events cannot create duplicate
    entitlements.
-   Associate entitlement with user, order item/product and version
    policy.
-   Handle guest checkout through a secure claim flow if guest checkout
    is enabled.
-   Revoke/restrict access according to refund/chargeback policy.

### PAY-010 Refunds

-   Require permission and a reason.
-   Validate refund amount against refundable balance.
-   Prevent duplicate or over-refunds.
-   Persist provider refund ID and status.
-   Update payment/order/ledger state from verified provider
    response/events.
-   Apply the documented entitlement policy.
-   Notify the customer and seller as appropriate.
-   Keep immutable refund history.

### PAY-011 Seller commission and ledger (multi-seller requirement)

-   Calculate commission using the policy effective for the order.
-   Persist commission/fee snapshots for historical transactions.
-   Record seller earnings, commission, fees, refunds, reserves and
    adjustments as ledger entries.
-   Do not use a mutable balance as the only financial record.
-   Make ledger entries immutable; corrections should use compensating
    entries.
-   Define treatment for disputes, chargebacks, negative balances and
    seller suspension.

### PAY-012 Payouts

If seller payouts are in scope: - Calculate withdrawable balance from
ledger entries and policy. - Validate minimum amount, currency, payout
method and account details. - Prevent duplicate concurrent requests. -
Require authorized approval and record reviewer/reason. - Track
requested, approved, processing, paid, rejected and failed states. -
Store provider reference and fees. - Never mark payout as paid solely
from a client or seller action. - Use dual approval for
high-risk/high-value payouts where feasible.

### PAY-013 Reconciliation

Provide a workflow to compare internal payment records with provider
status/settlement reports. Flag mismatches, missing webhooks, duplicate
events and unexplained amount/currency differences. Manual correction
must be audited and must not silently rewrite history.

### PAY-014 Notifications

Notify relevant users about payment success/failure, refund changes and
payout status. Notifications must not include provider secrets or
permanent private download URLs.

### PAY-015 Reporting

Report gross sales, net sales, refunds, fees, commission, seller
payable, payouts and currency. Define calculation and timezone rules. Do
not aggregate different currencies without a documented exchange-rate
basis.

## 5. Data model

Suggested tables: - `orders` - `order_items` - `payments` -
`payment_events` or webhook inbox - `refunds` -
`payment_reconciliation_items` (optional) - `seller_ledger_entries` -
`payout_requests` - `payouts` - `entitlements` - `activity_log`

Recommended constraints: - Unique provider event ID scoped by
provider. - Unique provider transaction/reference where provider
semantics allow. - Unique idempotency key for relevant operations. -
Foreign keys to orders, order items, users and sellers. - Indexes on
status, provider, transaction reference, order ID and timestamps. -
Monetary values with explicit currency. - Immutable purchase-time
snapshots.

## 6. Security and reliability

-   Never store raw card numbers or card security codes.
-   Keep provider secrets in secret management/environment.
-   Verify webhook signatures before processing.
-   Use database transactions for critical state transitions.
-   Enforce idempotency with database constraints, not only application
    checks.
-   Rate-limit checkout creation and sensitive financial actions.
-   Protect finance/admin routes with dedicated permissions.
-   Redact payment payloads before logging.
-   Restrict access to reconciliation and payout records.
-   Add alerting for webhook failures, queue backlog and reconciliation
    mismatches.
-   Test malformed, duplicate, delayed and out-of-order events.

## 7. Testing requirements

-   Valid/invalid webhook signatures.
-   Correct/wrong amount and currency.
-   Unknown order/payment references.
-   Duplicate webhook event.
-   Replayed event.
-   Out-of-order pending/succeeded/failed events.
-   Repeated checkout submission.
-   Provider timeout and retry.
-   Refund below, equal to and above refundable balance.
-   Duplicate refund request.
-   Entitlement issuance exactly once.
-   Refund/chargeback entitlement policy.
-   Seller commission and ledger arithmetic.
-   Duplicate payout requests and unauthorized payout approval.
-   Cross-currency reporting behavior.
-   Sandbox end-to-end checkout.

## 8. Acceptance criteria

-   [ ] A browser redirect alone never marks an order paid.
-   [ ] Invalid webhooks are rejected and logged safely.
-   [ ] Duplicate events cannot duplicate financial records or
    entitlements.
-   [ ] Amount and currency are verified against expected records.
-   [ ] Every financial state transition is validated and auditable.
-   [ ] Refunds cannot exceed refundable balance.
-   [ ] Seller ledger reconciles to orders, commissions, refunds and
    payouts if multi-seller is enabled.
-   [ ] Payouts cannot be self-approved or marked paid by a seller.
-   [ ] Provider secrets and payment credentials never appear in logs.
-   [ ] Automated tests cover failure, retry and concurrency cases.
-   [ ] Provider sandbox tests pass before production credentials are
    enabled.

## 9. Open decisions

-   Initial payment provider and merchant eligibility.
-   Supported currency/currencies.
-   Tax and invoice obligations.
-   Guest checkout policy.
-   Refund window and access revocation behavior.
-   Commission and fee policy.
-   Seller payout methods, minimums, schedule and reserves.
-   Chargeback/dispute workflow.
-   Subscription billing requirement.
-   Reconciliation frequency and finance approval roles.

## 10. Definition of done

The payment provider is validated against official documentation,
sandbox tests pass, webhook processing is signed and idempotent, orders
and entitlements remain consistent, financial actions are audited, and
finance/product/QA sign-off is recorded.
