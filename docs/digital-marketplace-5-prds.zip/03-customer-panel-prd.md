# PRD 03 --- Customer Panel

## Digital File Marketplace

**Version:** 1.0\
**Status:** Draft for implementation\
**Stack:** Laravel 13, PHP 8.5+, Livewire 4, Tailwind CSS 4

## 1. Purpose

The Customer Panel lets customers manage their account and security,
review orders and payment status, access purchased digital files, manage
download history and contact support through the features approved for
the product.

## 2. Goals

-   Provide a trustworthy account and purchase experience.
-   Make order/payment status understandable.
-   Provide reliable access to files the customer is entitled to
    download.
-   Let customers manage authentication factors and sessions.
-   Prevent access to another customer's personal information, orders or
    files.

## 3. Functional requirements

### CUS-001 Account dashboard

Show relevant summary information: recent orders, order statuses,
available downloads, security status and notifications. Metrics must
reflect real records and not expose other users' information.

### CUS-002 Profile

-   View/update permitted name, display name, email and profile fields.
-   Require email verification when email changes.
-   Re-authenticate for sensitive account changes.
-   Validate and normalize input.
-   Provide safe account deletion/deactivation request handling based on
    retention and legal requirements.

### CUS-003 Authentication and security

-   Password login, registration, verification and password reset.
-   Google OAuth with secure account linking.
-   TOTP 2FA enrollment, challenge, disablement and recovery codes.
-   Passkey registration/revocation if enabled and validated.
-   Session/device list and logout from other sessions where supported.
-   API token management only if exposed to customers.
-   Show recovery guidance without exposing stored secrets.
-   Use generic errors where revealing account existence would create
    risk.

### CUS-004 Order history

-   List only the authenticated customer's orders.
-   Filter by date, order number and status.
-   Show item snapshots, amounts, currency, payment state,
    receipt/reference and refund state where available.
-   Provide order detail with a clear timeline.
-   Do not allow customer-side editing of paid order totals or
    transaction status.

### CUS-005 Payment status

-   Show pending, paid, failed, cancelled and refunded states based on
    server records.
-   Explain pending confirmation without treating a browser redirect as
    proof of payment.
-   Allow safe retry/restart of checkout only where the existing
    order/provider state permits it.
-   Avoid duplicate order creation when a customer refreshes or returns
    from a provider.

### CUS-006 Purchased files

-   List products/files covered by active entitlements.
-   Display version/access policy, file metadata and available download
    action.
-   Request a fresh authorization check on every download.
-   Do not render a permanent public URL to a paid original.
-   Hide/restrict access after refund, revocation or other
    policy-defined state changes.
-   Explain unavailable/expired access clearly.

### CUS-007 Download history

Show allowed download events with timestamp, product/version and outcome
where appropriate. Do not expose internal storage paths or sensitive
infrastructure data. Define retention and privacy rules.

### CUS-008 Notifications

-   Order and payment updates.
-   Refund status.
-   New file version availability if included in entitlement policy.
-   Account security alerts and authentication-factor changes.
-   Allow preferences for non-critical notifications where supported.
-   Security-critical notifications cannot be silently disabled if
    policy requires delivery.

### CUS-009 Support and disputes

If support is in scope, allow customers to submit a support request
linked to an order. Validate ownership, rate-limit submissions and avoid
exposing internal staff notes. Refund/dispute requests must follow a
documented policy and are not automatically approved.

### CUS-010 Saved products (optional)

Allow wishlist/favorites only if approved for MVP. Keep them private by
default and do not imply a saved item has been purchased.

### CUS-011 Receipts and invoices

Provide receipts from authoritative order/payment records. Tax invoices
and jurisdiction-specific fields require a separate business/legal
decision. Never invent tax values or claim a document is a compliant
invoice until requirements are verified.

## 4. Security and privacy

-   Enforce order ownership and entitlement checks on the server.
-   Protect account changes with re-authentication where appropriate.
-   Use CSRF protections and rate limits.
-   Do not log passwords, TOTP codes, recovery codes or OAuth tokens.
-   Do not leak customer data through APIs, notifications, URLs or
    exception messages.
-   Define account/data retention and deletion behavior that preserves
    legally/operationally required financial records.
-   Escape user-generated content and validate uploaded profile media.

## 5. UI/UX requirements

-   Responsive account navigation.
-   Clear security setup guidance.
-   Order list with filters and status labels.
-   Download button states: available, processing, unavailable, limit
    reached and unauthorized.
-   Accessible form errors, loading feedback and empty states.
-   Confirmation for disabling 2FA, revoking a passkey or deleting
    account data.
-   Do not show a download action as available until server policy says
    it is available.

## 6. Data requirements

Likely entities: users, social_accounts, passkeys/package-managed
credentials, two-factor fields, orders, order_items, payments,
entitlements, download_events, notifications, support_tickets
(optional), activity_log.

Order ownership and entitlement relationships must be indexed and
enforced. Avoid duplicating payment status as an independently editable
customer field.

## 7. Acceptance criteria

-   [ ] Customer cannot view another customer's order or download list
    by changing an ID.
-   [ ] Customer cannot download a file without a valid entitlement.
-   [ ] Payment status is sourced from verified server-side events.
-   [ ] 2FA challenge and recovery code flows are tested if enabled.
-   [ ] Account linking and email-change flows require appropriate
    verification.
-   [ ] Refund/revocation policy is reflected in download access.
-   [ ] Security notifications do not expose secrets.
-   [ ] Profile and order pages meet accessibility/responsive
    requirements.
-   [ ] Pest tests cover ownership, authentication and entitlement
    failures.

## 8. Open decisions

-   Guest purchase claim flow.
-   Account deletion and financial-record retention policy.
-   Support tickets and dispute workflows in MVP.
-   Customer API token access.
-   Download limit and purchased-version/latest-version rules.
-   Receipt versus tax invoice requirements.

## 9. Definition of done

Customer account flows are accessible, private, tested and consistent
with authoritative order, payment and entitlement records.
