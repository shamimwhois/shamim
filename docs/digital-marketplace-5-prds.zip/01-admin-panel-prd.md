# PRD 01 --- Admin Panel

## Digital File Marketplace

**Version:** 1.0\
**Status:** Draft for implementation\
**Stack:** Laravel 13, PHP 8.5+, Livewire 4, Tailwind CSS 4, Alpine.js

## 1. Purpose

The Admin Panel is the privileged operations interface for managing the
marketplace, users, sellers, catalog, orders, payment oversight,
settings, security and auditability. It must enforce permissions
server-side and must not rely on hidden UI controls as an access-control
mechanism.

## 2. Goals

-   Provide secure, auditable control over marketplace operations.
-   Manage seller onboarding, verification, suspension and permissions.
-   Manage catalog structure, products, digital files and moderation.
-   Monitor orders, payment events, refunds and seller settlements.
-   Provide operational visibility without exposing passwords, OAuth
    tokens, TOTP secrets, recovery codes or payment credentials.

## 3. Roles and permissions

Use explicit roles and granular permissions. Suggested roles:
`super_admin`, `admin`, `catalog_manager`, `seller_manager`,
`support_agent`, `finance_manager`, `security_auditor`. These are
starting roles, not hardcoded authorization rules.

Sensitive actions require dedicated permissions, for example: -
`users.view`, `users.suspend` - `sellers.review`, `sellers.approve`,
`sellers.suspend` - `catalog.create`, `catalog.update`,
`catalog.publish` - `orders.view`, `orders.manage` - `payments.view`,
`refunds.create` - `payouts.view`, `payouts.approve` -
`settings.manage`, `audit.view`

Every action must be checked by Laravel policies/gates on the server.
Record sensitive actions in an audit log.

## 4. Functional requirements

### ADM-001 Dashboard

Show date-filtered, permission-aware metrics: - Gross sales, net sales,
refunds and pending payment totals. - Orders by status. - New customers
and sellers awaiting review. - Products awaiting moderation. - Pending
or failed payouts. - Recent operational/security events.

Metrics must be derived from persisted records and clearly define time
zone, currency and calculation rules. Do not show fake metrics in
production.

### ADM-002 Seller management

-   List/search/filter sellers by application status, verification
    status, sales and date.
-   Review seller application and submitted business/profile details.
-   Approve, reject, request more information, suspend or reactivate a
    seller.
-   Capture reviewer, decision, reason and timestamp.
-   Notify seller of decisions.
-   Prevent suspended sellers from creating new listings or receiving
    new orders, subject to documented policy.
-   Preserve order and financial history when a seller is suspended or
    deleted.

### ADM-003 Customer and staff management

-   Search users and view appropriate account/order summaries.
-   Suspend/reactivate accounts with reason and audit entry.
-   Assign staff roles and permissions.
-   Revoke sessions/tokens where supported.
-   Never expose password hashes, TOTP secrets, recovery codes or OAuth
    tokens.

### ADM-004 Catalog governance

-   Manage brands, device models, categories and subcategories.
-   Review reported or flagged products.
-   Publish, reject, archive or disable products.
-   Review file metadata, version, checksum and upload status.
-   Keep originals in private storage.
-   Preserve historical order snapshots when products change.

### ADM-005 Orders

-   Search/filter orders by order number, customer, seller, date and
    status.
-   View order items, immutable purchase-time prices, payment events and
    entitlement state.
-   Add internal notes with staff identity and timestamps.
-   Do not permit arbitrary edits to paid totals or order history.
-   Provide documented workflows for cancellation and dispute
    investigation.

### ADM-006 Payments and refunds

-   View provider, transaction ID, currency, amount, event status and
    sanitized failure details.
-   Inspect webhook processing status.
-   Retry only idempotent processing jobs.
-   Create refunds only with permission, valid provider support and a
    recorded reason.
-   Do not mark an order paid manually without a documented, audited
    exceptional workflow.
-   Keep payment reconciliation separate from ordinary order editing.

### ADM-007 Seller settlements and payouts

-   View seller payable balance, commission, refunds, reserves and
    payout history.
-   Approve/reject payout requests according to policy.
-   Use a ledger-based calculation; do not rely on mutable balance
    fields alone.
-   Record payout provider/reference, amount, currency, fees, status and
    audit history.
-   Require separation of duties for payout approval where operationally
    feasible.
-   Do not claim that a payout succeeded until provider/bank
    confirmation is recorded.

### ADM-008 Settings

Manage non-secret settings such as marketplace name, support contact,
catalog options, commission policy and feature flags. Store secrets in
environment/secret management, not plain editable settings. Changes to
payment, security or commission settings require privileged permission
and audit logging.

### ADM-009 Audit logs

Search by actor, event type, subject, date and outcome. Log
security-sensitive changes and administrative actions, but redact
credentials, tokens, passwords, OTPs and other secrets. Restrict log
access.

### ADM-010 Operational health

Provide visibility into queue failures, webhook backlog, storage
availability, scheduled task status and backup status where integrations
are available. Do not expose infrastructure secrets or internal details
to ordinary admins.

## 5. UI/UX requirements

-   Responsive dark technical dashboard with consistent design tokens.
-   Sidebar navigation based on permissions.
-   Searchable, filterable, paginated tables.
-   Loading, empty, error, success and retry states.
-   Confirmation dialogs for destructive and financial actions.
-   Accessible forms, keyboard navigation and visible focus states.
-   Clear separation between test/sandbox and live payment environments.

## 6. Data requirements

Likely entities: users, seller_profiles, seller_applications,
roles/permissions, brands, device_models, categories, products,
product_files/file_versions, orders, order_items, payments,
payment_events, refunds, seller_ledger_entries, payout_requests,
payouts, activity_log, admin_notes.

Use foreign keys, unique identifiers, appropriate indexes and immutable
financial snapshots. Do not delete financial history through cascading
deletes.

## 7. Security requirements

-   Server-side authorization for every admin route/action.
-   MFA required for privileged staff before production, preferably
    enforced through Fortify.
-   Re-authentication for high-risk actions.
-   CSRF protection for browser actions.
-   Rate limits for sensitive endpoints.
-   Audit trails for approvals, suspensions, refunds, payouts and
    settings changes.
-   No secrets in logs or UI.
-   Least-privilege database/storage credentials.
-   Financial operations must use transactions, idempotency and explicit
    state transitions.

## 8. Acceptance criteria

-   [ ] Unauthorized roles cannot access protected admin routes by
    direct URL or crafted requests.
-   [ ] Seller approval/rejection records actor, reason and timestamp.
-   [ ] Product moderation preserves order history.
-   [ ] Refund and payout actions require correct permission and produce
    audit entries.
-   [ ] Dashboard metrics reconcile with source records and documented
    currency/time rules.
-   [ ] Secrets and authentication factors are never displayed in admin
    screens or logs.
-   [ ] Tables support pagination and server-side filtering.
-   [ ] Pest feature tests cover allowed and denied operations.
-   [ ] Admin workflows have browser tests for critical actions.

## 9. Dependencies and open decisions

-   Final role/permission matrix.
-   Seller verification requirements and documents.
-   Commission, reserve and payout policy.
-   Refund and dispute policy.
-   Audit-log retention period.
-   Whether dual approval is required for high-value refunds/payouts.

## 10. Definition of done

All relevant tests pass, permissions are enforced server-side, financial
actions are audited, documentation is updated, and product/QA owners
sign off.
