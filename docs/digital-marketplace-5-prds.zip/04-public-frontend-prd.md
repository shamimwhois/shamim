# PRD 04 --- Public Frontend

## Digital File Marketplace

**Version:** 1.0\
**Status:** Draft for implementation\
**Stack:** Laravel 13, Livewire 4, Tailwind CSS 4, Alpine.js

## 1. Purpose

The public frontend is the customer-facing storefront for discovering
digital products/files, evaluating compatibility and pricing, learning
about sellers, creating an account and beginning checkout.

## 2. Goals

-   Make catalog discovery fast and understandable.
-   Present trustworthy product metadata and seller identity.
-   Provide a polished, responsive design.
-   Convert visitors into customers without misleading payment or
    download claims.
-   Keep private product files, unpublished content and sensitive seller
    data inaccessible.

## 3. Primary pages

1.  Home/landing page.
2.  Catalog browse page.
3.  Brand listing and brand detail.
4.  Device model listing/detail where relevant.
5.  Category/subcategory listing.
6.  Search results.
7.  Product/file detail page.
8.  Seller public profile/storefront.
9.  Cart or direct checkout entry point.
10. Login/register/forgot-password modal or pages.
11. Terms, privacy, refund, acceptable-use and support pages.
12. Error, unavailable and not-found pages.

## 4. Functional requirements

### PUB-001 Homepage

Show configurable featured products, categories, brands/devices,
recently published items and marketplace information. All content must
come from approved data or explicit static content; do not use fake
sales/review counts.

### PUB-002 Catalog browsing

-   Browse published products by category, brand and device.
-   Paginate results server-side.
-   Preserve filters in query parameters where useful.
-   Handle empty results and invalid filters.
-   Never expose draft, suspended or unpublished items.

### PUB-003 Search

Support keyword search across approved fields, with validated filters
for category, brand/device, price and relevant metadata. Use database
search initially if sufficient; adopt Scout/search engine only when
justified by scale or search needs.

### PUB-004 Product detail

Display: - Product title, seller, price/currency and availability. -
Description and permitted preview media. - Compatibility/device
metadata. - Version, release notes and safe file metadata. -
Refund/access policy summary. - Relevant purchase/download state for
authenticated customers. - Related products if configured.

Do not expose paid original URLs, internal storage paths, secrets or
unpublished versions.

### PUB-005 Seller public profile

Display only approved public profile fields and published products. Hide
private verification documents, legal/payment details, internal notes
and suspended/unpublished listings.

### PUB-006 Authentication entry points

Provide consistent custom UI for login, registration, Google OAuth,
passkeys and TOTP challenge as enabled. UI controls must call the
supported authentication flow and must not create a parallel auth
pipeline.

### PUB-007 Checkout entry

Allow customers to proceed to checkout for an available item. The server
must calculate price, verify product status and create/reuse the correct
pending order. Do not trust client-submitted price or payment success.

### PUB-008 SEO and sharing

-   Human-readable slugs and canonical URLs.
-   Page titles, descriptions, Open Graph metadata and sitemap for
    public published content.
-   Exclude account pages, private files, admin pages and unpublished
    products from public indexing.
-   Avoid exposing customer-specific purchase data in cached/shared
    HTML.

### PUB-009 Accessibility and responsiveness

-   Semantic HTML and labels.
-   Keyboard-operable menus and dialogs.
-   Visible focus indicators.
-   Accessible errors and adequate contrast.
-   Responsive behavior across mobile, tablet and desktop.
-   Respect reduced-motion settings.

### PUB-010 Performance

-   Paginate and eager-load catalog data.
-   Optimize preview images and static assets.
-   Cache public data only with clear invalidation.
-   Do not cache personalized order/download state in shared public
    caches.
-   Avoid loading heavy animation libraries without a clear UX benefit.

### PUB-011 Trust and policy content

Show clear pricing, currency, compatibility limitations, file version
and refund/access policy. Do not claim that a file is safe, official or
compatible unless the marketplace has a defensible basis for that claim.

## 5. Design system

Use a consistent component set: - Header/navigation and responsive
mobile menu. - Search field and filter controls. - Product card and
seller badge. - Price, status and version labels. - Buttons, inputs,
dropdowns, modal/dialog, toast/alert. - Pagination, breadcrumbs and
empty states. - Skeleton/loading states and retryable errors.

The preferred visual direction is a modern dark technical marketplace
with restrained red accents, crisp typography and high-contrast
controls. Exact color tokens should be documented in a separate
design-system file and reused across public, customer, seller and admin
areas.

## 6. Security and privacy

-   Public routes return published data only.
-   Validate all query and route parameters.
-   Escape user-generated descriptions and prevent stored/reflected XSS.
-   Use CSRF protections on state-changing browser requests.
-   Do not leak private seller/customer data through page source,
    metadata, JSON-LD or caches.
-   Rate-limit abusive search, authentication and checkout behavior
    where appropriate.
-   Keep paid originals private.

## 7. Acceptance criteria

-   [ ] Public visitors can browse and search published products.
-   [ ] Filters and pagination are validated and stable.
-   [ ] Draft/unpublished/suspended products are not publicly
    accessible.
-   [ ] Product details show accurate server-backed price and metadata.
-   [ ] No paid original file URL appears in public HTML.
-   [ ] Customer-specific purchase status is not shared through public
    cache.
-   [ ] Login/register entry points work with the central authentication
    flow.
-   [ ] Checkout cannot be manipulated by changing client-side prices.
-   [ ] Responsive and accessibility checks pass.
-   [ ] SEO metadata excludes private and unpublished pages.

## 8. Open decisions

-   Final brand/design tokens and visual assets.
-   Cart versus direct checkout.
-   Public reviews/ratings and moderation policy.
-   Wishlist scope.
-   Search engine selection.
-   Supported languages and localization.
-   Guest checkout.
-   Legal/refund content approved by the product owner.

## 9. Definition of done

The public storefront is responsive, accessible, search-friendly, backed
by real catalog data and cannot expose private product files or
customer-specific information.
