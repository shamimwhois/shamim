# API & Provider Sync PRD package

Files:
- `08-api-provider-sync-master-prd.md` — seller credentials, REST endpoints, prefixed public IDs, provider adapters, custom parameters, price rules, folders/files, automation and site-to-site sync.
- `openapi-v1-starter.json` — starter OpenAPI contract to expand before implementation, updated with admin API provider CRUD, connection test, key rotation, and seller API-key installation binding/email-verified rebind endpoints.

Important:
- `{BRAND_PREFIX}-{XXXX}-{XXXX}-{XXXX}-{XXXX}` is a readable public reference format, not a standard UUID and not an API secret. Keep a canonical UUID internally.
- Site-to-site synchronization must be directional per entity/field; bidirectional sync requires conflict detection and loop prevention.
- Provider integration must use authorized APIs and documented terms.
- Remote URL fetches require SSRF protections.

- Admin API provider configuration now explicitly includes `api_url`, `api_username`, and encrypted/write-only `api_key`, with test-connection, rotation, safe responses, validation, and SSRF protections.

- Seller API key policy v1.3: one active domain + approved hosting egress IP per key by default. Second-site use or IP/domain change requires seller email verification plus domain/server proof; origin headers alone are not trusted.


## v1.3 clarification
The seller API key and domain/IP/email verification flow authorizes external sync clients for catalog synchronization only. It is not an installation or software licensing service. Sync entities include IDs, names, descriptions, folders, files, categories, custom parameters, pricing and related metadata.
