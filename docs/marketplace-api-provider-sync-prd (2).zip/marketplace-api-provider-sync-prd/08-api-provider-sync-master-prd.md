# Master PRD — Seller REST API, Provider Integrations, Catalog Sync & Automation

- **Document ID:** API-PRD-001
- **Version:** 1.3
- **Date:** 2026-10-19
- **Stack:** Laravel 13, PHP 8.5+, Livewire 4, Tailwind CSS 4, Alpine.js, MySQL 8.4+, Laravel Sanctum, queues, private local/S3-compatible storage
- **Status:** Draft for technical review

## 1. Executive summary

Build a versioned REST API and automation subsystem that lets authorized seller accounts and approved external provider sites exchange brands, categories, folders, files, metadata, custom parameters and prices. The system supports provider adapters, API credentials, sync jobs, price transformations, webhook events, reconciliation, conflict resolution, logs and retry-safe automation.

The target integration pattern is **Site A → Site B → Site A**:
1. Site A exposes an authorized API.
2. Site B connects to Site A through a provider connection, fetches allowed entities, maps them into local entities and applies configured transformations.
3. Site B may expose its own API so Site A or another authorized site can retrieve data.
4. Direction is configured per entity and field. Two-way sync is not enabled implicitly.
5. Reconciliation identifies drift; conflicts are resolved using explicit policies or by an authorized reviewer.

A “folder” may mean a logical catalog folder or a remote provider folder. It must not be confused with a server filesystem path. External file records should be metadata-only unless authorized file transfer is explicitly configured.

## 2. Goals

- REST endpoints for seller profile, credentials, brands, categories, folders, files, parameters, providers, sync jobs and pricing rules.
- Canonical UUID identity plus a readable brand-prefixed public ID.
- Import/synchronize catalog metadata and approved file objects.
- Percentage markup, fixed adjustment, price override, limits, rounding and rule priority.
- Scheduled, manual, incremental and webhook-triggered sync.
- Idempotent processing, conflict detection, retry/backoff and operational reporting.
- Seller isolation, scoped credentials, audit logs and safe file handling.
- OpenAPI documentation and automated tests.

## 3. Non-goals

- Bypassing third-party authentication or syncing data without authorization.
- Scraping sites when an authorized API is available or required.
- Treating a public ID as an API secret.
- Blind two-way overwrite, infinite sync loops or uncontrolled deletion propagation.
- Arbitrary server-side code execution from custom provider/parameter configuration.
- Fetching arbitrary URLs without SSRF protection.

## 4. Shared architecture

- Laravel 13 / PHP 8.5+, subject to real dependency compatibility checks.
- Laravel Sanctum for suitable API token cases; evaluate OAuth2 client credentials for third-party machine integrations if needed.
- Laravel policies/gates and explicit permissions.
- MySQL with foreign keys, unique constraints and indexes.
- Laravel HTTP Client for outbound provider calls.
- Queue workers for imports, exports, transfers and reconciliation.
- Redis/Horizon when Redis is selected.
- Laravel Resources/DTOs for response allowlists.
- Provider adapters behind a stable application contract.
- Pest for unit, feature, adapter-contract and integration tests.
- Private storage for paid originals; public storage only for approved previews.
- All API routes versioned under `/api/v1`.
- Secrets stored encrypted or in environment/secret management, never returned in API responses or logged.

## 5. Public identifier format

Requested display format:

`{BRAND_PREFIX}-{XXXX}-{XXXX}-{XXXX}-{XXXX}`

Illustrative shape only:

`ACME-7KQ2-M9TP-4X6R-8VND`

### Required design
- `id`: canonical UUID/UUIDv7 as the internal immutable primary identity.
- `public_id`: unique, readable, prefixed reference for URLs/API responses.
- `brand_prefix`: validated uppercase ASCII letters/digits from configured brand/namespace.
- Suffix: cryptographically secure random bytes encoded with an unambiguous alphabet, e.g. Crockford Base32.
- Normalize and validate prefix; enforce length and allowed characters.
- Add a unique constraint and retry only on a uniqueness collision.
- Public ID is not a UUID in standard textual form and is not a secret.
- Never use public ID or UUID as proof of authorization; check ownership, permission and scope on every request.
- Decide whether uniqueness is global or per brand before migration design. Prefer globally unique public IDs if clients need unambiguous references.

## 6. Actors and permissions

### Admin
Manage seller API access, provider allowlists, global sync settings, pricing boundaries, conflict policies, audit logs and high-risk sync operations.

### Seller
Manage their own profile, credentials, provider connections, mappings, sync jobs, catalog and pricing rules within admin-defined limits. A seller cannot access another seller's credentials, files, jobs, prices or entities.

### Customer
No provider management by default. Customer-facing catalog and purchase/download APIs remain governed by the marketplace API policy.

### Service account
Machine-to-machine identity with narrowly scoped credentials and revocation/expiry controls.

Suggested token scopes:
- `catalog:read`
- `catalog:write`
- `sync:run`
- `sync:read`
- `providers:manage`
- `pricing:read`
- `pricing:manage`
- `files:read`
- `webhooks:receive`

## 7. REST conventions

- Base path `/api/v1`.
- JSON requests/responses, UTF-8 and UTC ISO-8601 timestamps.
- Paginated list endpoints with validated filters and sort allowlists.
- Consistent error format: `code`, safe `message`, optional `details`, `request_id`.
- Use `Idempotency-Key` for operations where retries could create duplicate work.
- Use version fields or ETags for conflict-sensitive updates.
- Apply per-token, per-seller and per-IP rate limits.
- Set maximum page size and bulk request size.
- Return `202 Accepted` and a job resource for asynchronous sync.
- Do not expose stack traces, SQL errors, provider secrets or filesystem paths.
- Maintain an OpenAPI contract with examples and error schemas.

Example success response:

```json
{
  "data": {
    "id": "ACME-7KQ2-M9TP-4X6R-8VND",
    "type": "file",
    "attributes": {}
  },
  "meta": {
    "request_id": "01J...",
    "api_version": "v1"
  }
}
```

Example error response:

```json
{
  "error": {
    "code": "SYNC_CONFLICT",
    "message": "The remote item changed after the last successful sync.",
    "details": [],
    "request_id": "01J..."
  }
}
```

## 8. Endpoint catalogue

These are proposed endpoints; implement only endpoints supported by product workflows and provider permissions.

### Seller account and API credentials
- `GET /api/v1/seller/profile`
- `PATCH /api/v1/seller/profile`
- `GET /api/v1/seller/api-credentials` — metadata only; never return existing secrets.
- `POST /api/v1/seller/api-credentials` — create scoped credential; show secret once.
- `POST /api/v1/seller/api-credentials/{credential}/rotate`
- `DELETE /api/v1/seller/api-credentials/{credential}`
- `POST /api/v1/seller/api-credentials/{credential}/sync-client-challenges` — start an email-verified sync-client add/change flow.
- `POST /api/v1/seller/api-credentials/{credential}/sync-client-challenges/confirm` — confirm email OTP and sync-client domain/source proof.
- `GET /api/v1/seller/api-credentials/{credential}/sync-clients` — list registered sync clients and statuses.
- `DELETE /api/v1/seller/api-credentials/{credential}/sync-clients/{sync_client}` — revoke a sync-client authorization.
- `GET /api/v1/seller/usage`

### Brands
- `GET /api/v1/brands`
- `POST /api/v1/brands`
- `GET /api/v1/brands/{brand}`
- `PATCH /api/v1/brands/{brand}`
- `DELETE /api/v1/brands/{brand}` — soft-delete/archive policy; never break historical orders.

### Categories
- `GET /api/v1/categories`
- `POST /api/v1/categories`
- `GET /api/v1/categories/{category}`
- `PATCH /api/v1/categories/{category}`
- `POST /api/v1/categories/{category}/archive`

### Folders
- `GET /api/v1/folders`
- `POST /api/v1/folders`
- `GET /api/v1/folders/{folder}`
- `PATCH /api/v1/folders/{folder}`
- `POST /api/v1/folders/{folder}/archive`

### Files and versions
- `GET /api/v1/files`
- `POST /api/v1/files` — create metadata or upload session, not arbitrary path assignment.
- `GET /api/v1/files/{file}`
- `PATCH /api/v1/files/{file}`
- `POST /api/v1/files/{file}/versions`
- `POST /api/v1/files/{file}/archive`
- `GET /api/v1/files/{file}/download` — entitlement/policy check, then authorized streaming or short-lived URL.

### Custom parameters
- `GET /api/v1/parameter-definitions`
- `POST /api/v1/parameter-definitions`
- `PATCH /api/v1/parameter-definitions/{definition}`
- `GET /api/v1/files/{file}/parameters`
- `PUT /api/v1/files/{file}/parameters`

### Admin API provider management and sync
Admin-only provider configuration endpoints (separate from seller-owned provider connections):
- `GET /api/v1/admin/api-providers` — list provider metadata, never raw secrets.
- `POST /api/v1/admin/api-providers` — create provider with `name`, `api_url`, `api_username`, `api_key` and optional operational settings.
- `GET /api/v1/admin/api-providers/{provider}` — retrieve safe configuration metadata.
- `PATCH /api/v1/admin/api-providers/{provider}` — update configuration; omit `api_key` to leave the existing key unchanged.
- `DELETE /api/v1/admin/api-providers/{provider}` — soft-delete/disable after checking active connections and jobs.
- `POST /api/v1/admin/api-providers/{provider}/test-connection` — perform a bounded, non-destructive connection check.
- `POST /api/v1/admin/api-providers/{provider}/rotate-key` — replace the stored key without returning the previous key.

Seller-facing provider connection endpoints (scoped to the authenticated seller):
- `GET /api/v1/providers`
- `POST /api/v1/providers`
- `GET /api/v1/providers/{provider}`
- `PATCH /api/v1/providers/{provider}`
- `POST /api/v1/providers/{provider}/test-connection`
- `POST /api/v1/providers/{provider}/sync-jobs`
- `GET /api/v1/providers/{provider}/sync-jobs`
- `GET /api/v1/sync-jobs/{job}`
- `POST /api/v1/sync-jobs/{job}/cancel`
- `POST /api/v1/sync-jobs/{job}/retry`
- `GET /api/v1/sync-jobs/{job}/items`
- `GET /api/v1/sync-conflicts`
- `POST /api/v1/sync-conflicts/{conflict}/resolve`
- `POST /api/v1/providers/{provider}/reconcile`

### Pricing
- `GET /api/v1/pricing-rules`
- `POST /api/v1/pricing-rules`
- `GET /api/v1/pricing-rules/{rule}`
- `PATCH /api/v1/pricing-rules/{rule}`
- `POST /api/v1/pricing-rules/{rule}/preview`
- `POST /api/v1/pricing-rules/{rule}/activate`
- `POST /api/v1/pricing-rules/{rule}/deactivate`

### Webhooks
- `POST /api/v1/webhooks/providers/{provider}`
- `POST /api/v1/webhooks/site-sync/{connection}`

Webhook endpoints must verify the provider's official signature/authentication contract, event identity and replay controls before processing.

## 9. API credential lifecycle

- Generate secrets with cryptographically secure randomness.
- Show raw secret only once.
- Store token hashes when supported by the selected credential implementation.
- Support scopes, expiry, revocation, rotation and last-used timestamps.
- Enforce per-token and per-seller quotas.
- Audit creation, rotation and revocation without logging secret values.
- Restrict credentials to approved resources and operations.
- Use HTTPS in production.
- CORS is not authentication.
- For external service-to-service clients, compare Sanctum token behavior with OAuth2 client credentials before finalizing the protocol; do not implement custom cryptography.

## 8A. Seller API key and email-verified sync-client authorization

**Purpose clarification:** This is a catalog synchronization integration, not an installation/licensing service. The purpose is to let a seller authorize one or more external websites to synchronize catalog records (brands, categories, folders, files, IDs, names, descriptions, custom parameters, prices and related metadata) through the REST API. Do not build software-installation tracking, product activation, license enforcement, or device-installation workflows.

### Seller credential and sync-client rules
- By default, each seller can generate one API key for their synchronization service. Admin policy may allow additional keys, but key count and sync-client count are separate settings.
- The seller registers a sync client using its canonical HTTPS domain and hosting server's outbound public IP (egress IP). The domain identifies the remote site; the observed source IP helps restrict server-to-server requests. The IP must be the server's actual egress IP, not necessarily the site's DNS A record.
- The first sync client is activated after the seller has authenticated, the key has been created, and domain control plus source-IP validation have succeeded.
- If the seller wants to use the same seller API key from a second website/domain or a different hosting IP, require email verification using the seller account's verified email before approving the additional sync client. Email verification is an approval step for adding a synchronization connection; it is not an installation license.
- After email verification, the seller can add a second sync client if the configured seller/admin policy allows it. The default policy can be one active sync client per key, in which case the seller must explicitly move/rebind the connection; do not silently allow a second active client. If multi-client use is enabled, enforce the configured limit.
- Email verification alone is insufficient: prove control of the new domain using DNS TXT or an HTTPS well-known challenge, and verify the request's observed source IP against the submitted egress IP policy.
- Do not trust `Origin` or `Referer` as server-to-server identity proof. Use a per-client identifier and signed HMAC requests (method, path, timestamp, nonce and body digest) or mTLS where supported. Reject stale timestamps and reused nonces.

### Sync client data model
Represent the remote site as a `sync_client` or `sync_connection`, never as an installation. Store `id`, `seller_id`, `credential_id`, `name`, normalized `domain`, optional `base_url`, `approved_egress_ip`/policy, `domain_verified_at`, `email_approved_at`, `status` (`pending`, `active`, `revoked`, `blocked`), `last_sync_at`, `last_seen_at`, `created_at`, `revoked_at`, and audit metadata. Keep credentials/secrets separate from catalog records. Do not store email OTPs in plaintext.

### First sync-client registration
1. Seller creates a scoped API key in the seller dashboard; show the raw secret once and store a hash where the chosen authentication design permits it.
2. Seller creates a sync connection with a descriptive name, HTTPS domain/base URL and fixed outbound public IP.
3. Issue a short-lived, single-use challenge. Verify domain control using DNS TXT or a well-known HTTPS token and verify the actual source IP on a signed server-to-server challenge request.
4. Activate the sync connection only after required proofs pass. Record an audit event and make the connection selectable in sync jobs.

### Adding a second sync client or changing its domain/IP
1. A new domain/IP is submitted through the authenticated seller dashboard or sync-connection API. Until approved, block sync operations for that proposed connection and return `SYNC_CLIENT_NOT_APPROVED`.
2. Send a short-lived email OTP/link to the seller's verified email. Rate-limit sends and attempts; bind the challenge to seller, credential, proposed domain/IP, and action; expire it after a short interval (recommended: 10 minutes).
3. Confirm the OTP/link while the seller is authenticated, then complete domain-control proof and source-IP validation. Email verification alone never activates the connection.
4. Apply the configured policy: either explicitly rebind and revoke the previous sync client atomically, or add a second active sync client when allowed. Keep an audit trail and enforce concurrency-safe limits.
5. Notify the seller after a new connection is approved, a connection is moved/rebound, or a key/connection is revoked.

### Request enforcement and security
- Each sync request must authenticate the API key, check credential status/scopes, identify the registered sync client, verify its signature/timestamp/nonce, and enforce its source-IP policy before reading or mutating catalog data.
- Domain headers are not authoritative; the verified sync-client record plus cryptographic request proof and source IP policy are authoritative.
- A changed egress IP or domain requires the email-verified sync-client change flow. Explicit admin policies may support dynamic egress IPs, but never silently trust arbitrary IP changes.
- Key rotation/revocation must be immediate or follow an explicitly configured short overlap window. Revoking a sync client must stop future sync jobs and API access for that client without deleting catalog data.
- Keep this mechanism separate from product/license activation. A sync-client record only represents a trusted external site allowed to synchronize catalog data.

### Error codes
- `SYNC_CLIENT_NOT_APPROVED` — caller's sync connection is not approved.
- `SYNC_CLIENT_VERIFICATION_REQUIRED` — email/domain/IP proof is pending.
- `SYNC_CLIENT_CHALLENGE_EXPIRED` — challenge expired or already consumed.
- `SYNC_CLIENT_LIMIT_REACHED` — seller policy disallows another active sync connection.
- `SYNC_CLIENT_SIGNATURE_INVALID` — signature, timestamp or nonce check failed.

### Acceptance criteria
- Seller API keys authorize catalog synchronization only; no installation/license lifecycle is implemented.
- A second domain/IP cannot start synchronization until the seller's verified email approval and domain/source proof pass.
- Multi-client allowance is an explicit policy; default single-client mode requires an explicit rebind.
- Invalid, expired, replayed and brute-forced email challenges are rejected and rate-limited.
- Caller-supplied `Origin`/`Referer` alone never authorizes a sync request.
- Revoking a sync connection blocks sync requests/jobs but does not delete folders, files, categories, metadata or mappings.
- Tests cover first sync-client registration, second-client email approval, denied unverified sync, proof failure, IP mismatch, replay, rate limits, rebind races, rotation and revocation.

## 10. Provider adapter contract

Suggested interface:

```php
interface ProviderAdapter
{
    public function testConnection(ProviderConnection $connection): ConnectionResult;
    public function fetchBrands(SyncContext $context): PageResult;
    public function fetchCategories(SyncContext $context): PageResult;
    public function fetchFolders(SyncContext $context): PageResult;
    public function fetchFiles(SyncContext $context): PageResult;
    public function fetchFileParameters(SyncContext $context, string $remoteId): ParameterResult;
    public function supportsIncrementalSync(): bool;
    public function normalizeWebhook(array $payload, array $headers): NormalizedProviderEvent;
}
```

Adapters must normalize remote IDs, pagination, timestamps, statuses, prices and custom parameters. They must handle provider quotas, bounded timeouts, transient/permanent failures, retry/backoff and sanitized errors. Provider-specific APIs and payloads must not leak throughout the application. Use fake HTTP responses and contract tests. Never execute arbitrary code from provider configuration.

## 10A. Admin API provider configuration (required)

The Admin Panel must provide an **API Provider Management** CRUD screen. The minimum credential fields are exactly:

| Field | Storage / validation | Rules |
|---|---|---|
| `api_url` | `TEXT` or bounded `VARCHAR`; validated URL | Require HTTPS in production; reject credentials embedded in URL; validate host and every redirect to prevent SSRF. |
| `api_username` | `VARCHAR`, nullable only if the provider does not require it | Treat as secret-adjacent configuration; never include in public API responses. |
| `api_key` | encrypted text at rest; write-only in API/UI | Never return the plaintext value after creation; redact from logs, exceptions, audit payloads and exports. An omitted update value means “keep current key”; explicit rotation replaces it. |

Recommended provider fields include `id` (UUID), `name`, `driver`/`adapter_key`, `status` (`active`/`inactive`), `timeout_seconds`, `connect_timeout_seconds`, `retry_limit`, `last_tested_at`, `last_test_status`, `last_error_code`, `created_at`, and `updated_at`. Store credentials using Laravel encrypted casts or a dedicated secrets manager; ensure encryption keys are managed outside the database and are backed up securely. Never commit real credentials to source control or seed production secrets.

### Admin UI requirements
- Add, view, edit, disable, soft-delete, test connection and rotate API key.
- Show the API URL and username according to admin permissions, but mask the API key (for example, `••••••••`) after save. Do not provide a “reveal existing key” action.
- On edit, an empty API-key field means “unchanged”; use a separate explicit rotate/update action to replace it.
- Show last test timestamp, success/failure status, sanitized error message, and latency where available.
- Confirm destructive actions and prevent deletion while active sync jobs are running; require disable/cancel or a safe migration first.
- Apply admin authorization, policy checks, validation, CSRF protection for web actions, rate limits on connection tests and immutable audit events for create/update/disable/delete/rotation/test.
- Connection testing must use a provider adapter's documented, non-destructive health/account endpoint. Do not assume a universal endpoint or blindly send credentials to arbitrary URLs.

### Suggested database table: `api_providers`
- `id` UUID primary key
- `name` string
- `driver` string (registered adapter key; never executable class input)
- `api_url` text
- `api_username` string nullable
- `api_key` text (encrypted application-level value)
- `status` string/indexed
- `timeout_seconds` unsigned small integer with safe bounds
- `retry_limit` unsigned tiny integer with safe bounds
- `last_tested_at` nullable timestamp
- `last_test_status` nullable string
- `last_error_code` nullable string (sanitized, no secret values)
- timestamps and optional `deleted_at`

Use a separate `provider_connections` table for seller-specific connections to an admin-managed provider, including seller ID, provider ID, per-connection overrides that are explicitly allowed, mappings and sync configuration. Do not mix global provider credentials with seller-owned credentials. If credentials vary per seller, store them in a separately encrypted connection secret field and enforce tenant isolation.

### Security acceptance criteria
1. API responses, logs and audit events never contain the plaintext `api_key`.
2. A create/update request validates `api_url`, length limits, status, timeout and retry bounds.
3. A PATCH without `api_key` preserves the currently encrypted key.
4. Key rotation invalidates/replaces the previous key and writes an audit event without recording either key.
5. Test-connection has strict timeout/rate limits, validates destination/redirects, and reports only sanitized errors.
6. Seller tokens cannot read or mutate admin provider definitions; only authorized admins can access these routes.
7. Inactive or soft-deleted providers cannot start new sync jobs, while existing jobs are handled according to an explicit cancellation/drain policy.

## 11. Data mapping

Suggested tables/entities:
- `provider_connections`
- `provider_entity_mappings`
- `sync_jobs`
- `sync_job_items`
- `sync_cursors`
- `sync_conflicts`
- `webhook_inbox`
- `parameter_definitions`
- `entity_parameter_values`
- `pricing_rules`
- `pricing_rule_assignments`
- framework-managed API token records
- activity/audit log

Mapping records include provider connection, entity type, remote ID, local UUID/public ID, remote version/hash, last successful sync, sync direction, source-of-truth policy, status and last error code. Add unique constraints to prevent duplicate remote mappings. Normalize fields used for filtering; use constrained JSON only for genuinely flexible provider metadata.

## 12. Site A → Site B → Site A sync design

### Safe baseline
Start with one-way Site A → Site B synchronization. Enable reverse sync only after field ownership, conflict policy and loop prevention are tested.

### Workflow
1. Admin/seller creates a provider connection and securely configures credentials.
2. Validate the base URL against an approved host/domain policy and test connection.
3. Select entity types: brands, categories, folders, files, parameters and optionally prices.
4. Select field mappings, direction, ownership policy and price rules.
5. Run a dry-run preview showing creates, updates, unchanged records, skips and conflicts.
6. Queue a sync job with an immutable configuration snapshot.
7. Fetch pages using pagination or provider cursor.
8. Normalize and validate each source record.
9. Resolve mapping by provider ID and local UUID/public ID.
10. Compute a diff and apply only permitted changes.
11. Record item-level success/skip/failure and advance cursor only according to documented success rules.
12. Notify the user and provide a report.
13. Run reconciliation to detect drift.

### Loop prevention
Every outbound event should carry `event_id`, `origin_site_id`, `correlation_id`, `causation_id`, `entity_version` and `sync_direction`. Persist processed event IDs with a unique constraint. Ignore already processed events and changes caused by the same sync chain. Use content hashes/version numbers to detect no-op updates. Add a hop limit. A delay alone is not loop prevention.

### Field ownership
- Source-owned: source may update destination fields.
- Destination-owned: local edits do not push back.
- Admin-owned: local admin values win.
- Bidirectional: explicit merge/conflict policy required.
- Financial, permission, ownership and price fields must never silently use last-write-wins.

### Conflict resolution
If both sites changed a field since the last successful sync, record base/source/destination values or hashes and versions. Apply a configured field-level merge only when explicitly safe; otherwise require an authorized reviewer. Record the chosen resolution, actor, reason and resulting version.

### Deletion policy
Remote deletion must not hard-delete local records automatically. Use tombstones/archive states and opt-in deletion propagation. Preserve historical order references.

## 13. Pricing rules and percentage markup

Supported rules:
- Percentage markup: `source_price × (1 + percent / 100)`.
- Fixed adjustment.
- Fixed override.
- Minimum/maximum clamp.
- Provider/category/brand/seller-specific rules.
- Currency conversion only through a configured, documented rate source.
- Currency-aware rounding.
- Priority and effective date.
- Preview, activation, deactivation and version history.

Example: source price 100.00 with 15% markup gives 115.00 before rounding. If a fixed +5.00 adjustment applies afterward, result is 120.00. Rule order must be explicit.

Requirements:
- Store source price/currency separately from destination price/currency.
- Store applied rule ID/version.
- Use integer minor units or decimal-safe arithmetic; never binary floating-point for money.
- Define operation order, e.g. conversion → percentage → fixed adjustment → min/max → currency rounding.
- Preview affected count and sample results before activation.
- Enforce admin-defined boundaries on seller rules.
- Do not rewrite historical order snapshots.
- Log before/after values and actor for manual overrides.
- Reject missing price, invalid currency and negative result unless explicitly supported.

## 14. Custom parameters

Each parameter definition includes stable key, label, data type, validation schema, required flag, allowed values, unit, visibility, sync direction, conflict policy and provider-field mapping. Supported types may include string, integer, decimal, boolean, enum, date, URL and schema-validated JSON.

Prevent arbitrary code, SQL fragments, template execution, unsafe dynamic query construction and unbounded nested JSON. Enforce maximum value size and nesting depth. Parameter visibility can be internal, seller-visible or public.

## 15. Folders, files and secure remote fetch

Folder types:
- Logical catalog folder.
- Remote provider folder metadata.
- Storage object key (internal implementation detail; never client-controlled).

File modes:
- Remote reference only.
- Metadata-only catalog item.
- Imported private object.
- Versioned private object.

Remote URLs are not automatically safe or authorized. Validate provider host allowlists, prevent SSRF, block loopback/private/link-local addresses, validate redirects and prefer HTTPS. Never fetch arbitrary user-submitted URLs without SSRF protections. Store paid originals privately; verify entitlements on every download. Do not expose storage paths.

## 16. Automation and scheduling

- Manual sync with dry-run preview.
- Scheduled full sync.
- Incremental sync using cursor/updated timestamp when supported.
- Webhook-triggered updates.
- Periodic reconciliation.
- Exponential backoff with jitter for transient failures.
- Terminal/dead-letter state after configured attempts.
- Per-provider concurrency limits and per-scope locks.
- Pause/resume connections.
- Safe cancellation of queued or cancellable jobs.
- Completion/failure/conflict notifications.
- Maintenance windows and rate limits.
- Idempotent jobs and item-level checkpoints.
- Summary metrics: fetched, created, updated, unchanged, skipped, failed, conflicts, duration and cursor.

## 17. Security requirements

- HTTPS in production.
- Encrypt provider credentials at rest; redact all secrets.
- Enforce seller ownership and token scopes on every endpoint.
- Authorize seller API keys for registered sync clients using verified domain plus approved hosting egress IP; a second sync client requires seller email verification and domain/server proof.
- Do not trust Origin/Referer headers alone; use sync-client-bound HMAC signatures or mTLS plus nonce/timestamp replay protection.
- Validate webhook signature and replay controls.
- Rate-limit and cap request sizes, page sizes and batch sizes.
- Validate all transformation and custom parameter definitions.
- Require permissions for price-rule activation, credential rotation and destructive sync.
- Audit provider configuration, sync, conflict resolution and credential changes.
- Protect against cross-seller IDOR.
- Protect remote fetches against SSRF.
- Never expose original file paths or API secrets.
- Log request IDs and sanitized error codes only.

## 18. Observability

Track request volume/latency/status, provider quotas, queue lag, retry/dead-letter counts, sync throughput, item outcomes, conflict count/age, webhook processing latency and last successful sync. Alerts must be configurable. Logs must not contain bearer tokens or raw sensitive payloads.

## 19. Testing requirements

### Unit tests
- Public ID normalization and uniqueness handling.
- Pricing order, rounding, clamps and invalid values.
- Mapping resolution and conflict rules.
- Cursor advancement and state transitions.
- Event loop prevention and processed-event uniqueness.

### Feature tests
- Seller token scopes and ownership.
- One-key/one-sync-client authorization, email-verified second sync-client/add-or-rebind flow, domain challenge, source-IP enforcement, signed-request replay protection and immediate revocation.
- CRUD for brands/categories/folders/files.
- Custom parameter validation.
- Provider configuration authorization.
- Sync job create/status/cancel/retry.
- Price preview/activation permissions.
- Conflict resolution and audit events.

### Integration tests
- Provider adapter contract with HTTP fakes.
- Pagination and incremental cursors.
- Retry/backoff behavior.
- Invalid signature and replay rejection.
- Site A → Site B import and controlled reverse export.
- Duplicate events and loop prevention.
- SSRF/redirect/private-IP blocking.
- Private storage isolation.

### End-to-end acceptance tests
1. Configure a test provider.
2. Preview import without writes.
3. Run sync and inspect per-item counts.
4. Re-run unchanged data and verify no duplicate entities.
5. Modify source data and verify expected mapped fields update.
6. Modify both sites and verify conflict handling.
7. Apply percentage markup and verify preview and stored prices.
8. Revoke a token and verify access is denied.
9. Verify seller A cannot access seller B's provider, sync job or file.

## 20. Acceptance criteria

- [ ] Public IDs follow the configured prefixed grouped format and are unique.
- [ ] Canonical UUID remains the stable internal identity.
- [ ] Public ID/UUID never substitutes for authorization.
- [ ] Credentials are scoped, revocable and shown only once.
- [ ] APIs support brands, categories, folders, files and custom parameters.
- [ ] Provider adapters normalize data and handle pagination/errors.
- [ ] Sync jobs are asynchronous and report progress/status.
- [ ] Duplicate events/jobs do not duplicate records or repeat non-idempotent effects.
- [ ] Site-to-site sync cannot loop indefinitely.
- [ ] Conflicts are detected and resolved by explicit policy.
- [ ] Pricing supports percentage, fixed adjustment, clamps and rounding.
- [ ] Price previews show source and calculated prices before activation.
- [ ] Remote fetch is protected against SSRF.
- [ ] Private files and credentials remain inaccessible to unauthorized users.
- [ ] Audit and operational metrics are available to authorized staff.
- [ ] Tests cover success, failure, retry, conflict and cross-seller denial.

## 21. Roadmap

### Phase 0 — Discovery
Confirm provider APIs/permissions, public ID alphabet, entity ownership, file import mode, pricing order and conflict policy.

### Phase 1 — API foundation
Versioned routes, Resources, policies, token lifecycle, rate limits, CRUD, public IDs and OpenAPI.

### Phase 2 — Provider adapters
Connection model, encrypted credentials, test connection, pagination, normalization and adapter tests.

### Phase 3 — Sync engine
Queue jobs, item checkpoints, cursors, dry run, diffs, idempotency, conflicts and audit trail. Deliver one-way A → B first.

### Phase 4 — Pricing and custom parameters
Parameter definitions, field mapping, price previews, rule versioning and currency-safe calculations.

### Phase 5 — Controlled two-way sync
Field ownership, event causality, loop prevention, conflict UI, tombstones and reconciliation.

### Phase 6 — Production hardening
Security tests, SSRF review, load/rate-limit tests, monitoring, runbooks and staging sign-off.

## 22. Open decisions

1. Exact brand prefix source and alphabet.
2. Global or per-brand uniqueness for public IDs.
3. Which site owns each entity and field.
4. Approved provider APIs and their terms/limits.
5. Remote reference versus imported file content.
6. Pricing formula order and supported currencies.
7. Sync schedule and provider quotas.
8. Conflict owner and resolution SLA.
9. Sanctum token versus OAuth2 client credentials for third-party clients.
10. Retention policy for sync logs and provider payloads.

## 23. Definition of done

The approved API is documented; scopes and ownership are enforced; adapters pass contract tests; sync is idempotent and loop-safe; pricing previews match stored calculations; secrets remain protected; SSRF defenses pass; and product, engineering and security owners sign off.
