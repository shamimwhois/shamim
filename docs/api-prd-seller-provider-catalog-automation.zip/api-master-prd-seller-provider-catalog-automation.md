# API Master PRD — Seller Accounts, Provider Aggregation, Catalog Sync & Automated Pricing

**Document ID:** API-PRD-001  
**Version:** 1.0  
**Date:** 2026-10-19  
**Status:** Draft for engineering review  
**Stack:** Laravel 13, PHP 8.5+, Livewire 4, Tailwind CSS 4, Alpine.js, MySQL 8.4+, Sanctum, queues  
**API:** REST JSON, versioned under `/api/v1`

## 1. Executive Summary

Build a first-party REST API and automation layer for seller accounts, folders, files, categories, custom parameters, provider integrations, catalog synchronization and automated pricing. Provider data is normalized into a canonical internal model, deduplicated, mapped, priced and published according to policy.

Core capabilities:
- Seller accounts and scoped API tokens.
- UUID identifiers plus branded human-readable codes.
- Folder/file/category CRUD.
- Provider registry, encrypted credentials, adapter configuration and health checks.
- Provider catalog synchronization with mapping, deduplication, checkpoints and error reports.
- Custom metadata/parameter schemas.
- Markup percentage, fixed additions, per-provider/category/item overrides, rounding and price history.
- Scheduled/manual automation, dry runs, retries, alerts and audit trails.
- Tenant isolation, rate limiting, idempotency and secret redaction.

Provider APIs differ. Each provider must use a dedicated adapter that normalizes its authentication, payloads, pagination, errors and capabilities. Never assume all providers share the same endpoints or fields.

## 2. Goals and Non-Goals

### Goals
1. Provide stable REST endpoints for seller and admin workflows.
2. Use UUID as canonical identity and branded code as a unique alternate reference.
3. Enforce seller ownership on every request.
4. Automate safe retrieval and reconciliation of folders, files and categories.
5. Apply deterministic and explainable price rules.
6. Make provider sync observable, retry-safe and auditable.
7. Protect provider credentials, private files and sensitive metadata.

### Non-goals
- Arbitrary code/SQL execution from API parameters.
- Returning stored provider secrets after creation.
- Treating external provider payloads as trusted.
- Publishing every imported record without configured approval rules.
- Using public codes as authorization tokens.
- Copying or redistributing provider files without appropriate rights.

## 3. Shared Architecture

`REST API → Authentication → Rate limit → Validation → Policy/tenant scope → Action → Domain service → Database/provider adapter → Audit event → JSON Resource`

Provider sync flow:

`Trigger → Sync run → Provider adapter → Validate/normalize → Map categories/folders/files → Deduplicate/upsert → Apply pricing → Review/publish → Report`

### Modules
- `Accounts`: seller profiles, API clients, token abilities.
- `Catalog`: folders, files, versions, categories, subcategories.
- `Providers`: provider registry, credential references, adapters, health checks.
- `Sync`: runs, checkpoints, mappings, conflict handling and reports.
- `Pricing`: markup rules, overrides, rounding, history.
- `Automation`: schedules, triggers, retries, run logs and alerts.
- `Audit`: security and administrative event records.
- `API`: controllers, requests, resources, policies and versioning.

### Technology/package policy
- Laravel 13 and PHP 8.5+ must be verified against the actual dependency lockfile.
- Use Sanctum for suitable API-token use cases.
- Use Laravel policies/gates and explicit permissions.
- Use Laravel HTTP Client or provider SDKs behind contracts.
- Use queues for sync/bulk work; use Redis/Horizon if Redis is selected.
- Use Pest for unit, feature, integration and contract tests.
- Do not assume package versions are compatible without resolving and testing them.

## 4. UUID and Branded Code Format

UUID is the canonical ID and foreign-key reference. Prefer UUIDv7 if supported by the selected libraries/database conventions; UUIDv4 is acceptable otherwise.

Example branded code:

`GSMWHALE-1A2B-3C4D-5E6F-7A8B`

Rules:
- Prefix is configured by the platform/tenant, not freely chosen in a request.
- Generate segments using a cryptographically secure random source or approved unique-code generator.
- Normalize stored codes to uppercase.
- Add a unique database index on the full code.
- Retry boundedly on collision, then fail safely and alert.
- Public codes are references, not secrets or authorization tokens.
- UUID remains canonical for relationships; branded code is an alternate unique identifier.

Example:
```json
{
  "id": "0199f6c8-7d21-7a42-9c8f-6fce2a8b4210",
  "code": "GSMWHALE-1A2B-3C4D-5E6F-7A8B",
  "type": "catalog_file",
  "status": "active"
}
```

## 5. Roles and Authorization

Suggested roles: `super_admin`, `admin`, `provider_manager`, `catalog_manager`, `finance_manager`, `seller`, `seller_staff`, `read_only_auditor`.

- Scope seller-owned queries by the authenticated seller.
- Ignore or validate client-supplied `seller_id`; never trust it.
- Sellers cannot change global provider credentials or global pricing policy.
- Provider credentials and global provider settings are admin-only.
- Seller overrides must obey configured limits and approval policy.
- Bulk operations require explicit permissions, batch limits and idempotency.
- Audit every privileged provider/configuration change.
- Suspended sellers cannot write, sync or publish except through explicitly allowed appeal/status workflows.

## 6. Seller Account API

Base path: `/api/v1/seller`

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/v1/seller/account` | Current seller profile/status |
| PATCH | `/api/v1/seller/account` | Update permitted profile fields |
| GET | `/api/v1/seller/api-clients` | List own API client metadata |
| POST | `/api/v1/seller/api-clients` | Create scoped API token/client |
| DELETE | `/api/v1/seller/api-clients/{client}` | Revoke token/client |
| GET | `/api/v1/seller/usage` | Usage and quota summary |
| GET | `/api/v1/seller/audit-events` | Seller-visible audit events if enabled |

Tokens must have least-privilege abilities, revocation and an expiry policy. Show the token only once where appropriate; store tokens using the supported token system, not as plaintext API keys.

## 7. Folder API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/v1/seller/folders` | List own folders |
| POST | `/api/v1/seller/folders` | Create folder |
| GET | `/api/v1/seller/folders/{folder}` | Read folder |
| PATCH | `/api/v1/seller/folders/{folder}` | Update metadata |
| DELETE | `/api/v1/seller/folders/{folder}` | Archive/delete if safe |
| GET | `/api/v1/seller/folders/{folder}/files` | List folder files |
| POST | `/api/v1/seller/folders/{folder}/sync` | Trigger allowed sync |

Folder fields: UUID `id`, branded `code`, owner, `parent_id`, name, slug, description, source type, provider ID, external folder ID, status, validated metadata and `last_synced_at`.

Rules:
- Prevent moving a folder into itself or a descendant.
- Upsert provider folders by stable `(provider_id, external_folder_id)`.
- Archive rather than hard-delete if files/orders reference the folder.
- Configure maximum hierarchy depth and pagination.
- Sync must be idempotent and preserve ownership.

## 8. File API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/v1/seller/files` | List own files |
| POST | `/api/v1/seller/files` | Create file metadata |
| GET | `/api/v1/seller/files/{file}` | Read file metadata |
| PATCH | `/api/v1/seller/files/{file}` | Update permitted fields |
| DELETE | `/api/v1/seller/files/{file}` | Archive/remove if safe |
| POST | `/api/v1/seller/files/{file}/upload` | Upload through protected flow |
| POST | `/api/v1/seller/files/{file}/versions` | Create version |
| GET | `/api/v1/seller/files/{file}/versions` | List versions |
| POST | `/api/v1/seller/files/{file}/sync` | Refresh provider metadata |
| POST | `/api/v1/seller/files/bulk-sync` | Queue bounded bulk sync |

File fields: UUID, branded code, folder/category IDs, name/slug/description, MIME type, size, checksum, private storage key, source type, provider/external ID, version, status, validated metadata, price, currency and last sync time.

- Keep paid originals private.
- Validate file size, type/signature, filename and permission.
- Do not expose raw storage keys.
- Separate metadata endpoints from download endpoints.
- Verify provider license/contract before copying or redistributing files.
- Use explicit status transitions and preserve historical version references.

## 9. Category API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/v1/seller/categories` | List permitted categories |
| POST | `/api/v1/seller/categories` | Create seller category if allowed |
| GET | `/api/v1/seller/categories/{category}` | Read category |
| PATCH | `/api/v1/seller/categories/{category}` | Update category |
| DELETE | `/api/v1/seller/categories/{category}` | Archive/delete with reference checks |
| GET | `/api/v1/seller/categories/{category}/files` | List categorized files |
| POST | `/api/v1/seller/categories/{category}/sync` | Sync category mapping |

Category fields: UUID, branded code, parent ID, name, slug, description, sort order, status, source type, provider ID, external category ID, optional parameter schema and sync metadata.

Global taxonomy is admin-owned unless a permission explicitly permits otherwise. Sellers may map provider categories to global categories without gaining authority to mutate the global taxonomy.

## 10. Custom Parameters

Provider fields may differ: brand, model, region, file type, service code, device variant or provider-specific attributes. Use schema-validated data, not arbitrary executable values.

Each schema field may define:
- `key` (stable snake_case), `label`, `type`.
- Type: string, integer, decimal, boolean, enum, date, URL or constrained JSON.
- Required/default, enum values, min/max, length limits.
- Visibility to seller/customer/admin.
- Sensitive flag and source.
- Schema version.

Endpoints:
- `GET /api/v1/seller/parameter-schemas`
- `POST /api/v1/seller/parameter-schemas` (seller-owned schemas only if permitted)
- `GET /api/v1/seller/parameter-schemas/{schema}`
- `PATCH /api/v1/seller/parameter-schemas/{schema}`
- `POST /api/v1/seller/files/{file}/parameters`
- `GET /api/v1/seller/files/{file}/parameters`

Rules:
- Reject unknown keys unless schema explicitly allows them.
- Validate type/range/enum server-side.
- Never evaluate parameter values as PHP, SQL, shell commands, templates or arbitrary fetch instructions.
- Encrypt or exclude sensitive values as appropriate.
- Version schema changes without corrupting existing records.
- Retain only sanitized raw provider payloads when justified.

## 11. Provider Registry and Admin API

Base path: `/api/v1/admin/providers`

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/v1/admin/providers` | List providers without secrets |
| POST | `/api/v1/admin/providers` | Register provider configuration |
| GET | `/api/v1/admin/providers/{provider}` | Provider details/health |
| PATCH | `/api/v1/admin/providers/{provider}` | Update safe settings |
| DELETE | `/api/v1/admin/providers/{provider}` | Disable/archive provider |
| POST | `/api/v1/admin/providers/{provider}/test-connection` | Test connectivity |
| POST | `/api/v1/admin/providers/{provider}/sync` | Start sync run |
| GET | `/api/v1/admin/providers/{provider}/sync-runs` | List sync history |
| GET | `/api/v1/admin/providers/{provider}/sync-runs/{run}` | Read sync report |
| POST | `/api/v1/admin/providers/{provider}/sync-runs/{run}/retry` | Retry safe failed work |
| GET | `/api/v1/admin/providers/{provider}/mappings` | List field/category mappings |
| PUT | `/api/v1/admin/providers/{provider}/mappings` | Replace validated mappings |

Provider fields: UUID, slug, display name, allowlisted adapter key, base URL, auth type, encrypted credential/secret reference, timeout, rate limits, retry policy, enabled state, capabilities and last health/sync status.

Security:
- Never accept arbitrary class names from requests.
- Adapter key must resolve through an application allowlist.
- Prevent SSRF: validate scheme/host, block loopback/link-local/private/reserved IPs unless explicitly allowlisted, validate DNS/redirect behavior and prefer HTTPS.
- Sellers cannot set global provider credentials.
- Secrets are write-only and redacted from responses/logs.
- Use timeouts, concurrency limits, backoff and circuit-breaking where appropriate.

## 12. Provider Adapter Contract

Each adapter implements an internal contract equivalent to:
- `healthCheck()`
- `listFolders(cursor, parameters)`
- `listFiles(folderExternalId, cursor, parameters)`
- `listCategories(cursor, parameters)`
- `getItem(externalId)`
- `normalizeFolder(payload)`
- `normalizeFile(payload)`
- `normalizeCategory(payload)`

Optional order placement/status/balance operations are implemented only when the provider actually supports them and the product requires them.

Provider-specific parsing remains inside the adapter. Return validated DTOs/normalized arrays. Never let provider payload fields drive arbitrary mass assignment or database column names.

## 13. Catalog Sync and Automation

Modes:
- Manual admin-triggered sync.
- Scheduled full sync.
- Incremental sync using cursor/updated timestamp if supported.
- Targeted folder/category/file sync.
- Retry failed items.
- Dry-run/preview.
- Reconciliation for changes/deletions.

Run states: `queued`, `running`, `completed`, `completed_with_errors`, `failed`, `cancelled`, `dry_run_completed`.

Rules:
1. Create a sync-run record before queueing work.
2. Use unique run/job keys to avoid duplicate overlapping syncs.
3. Save checkpoints after successful pages.
4. Validate and normalize every provider record.
5. Upsert by `(provider_id, external_id)` or another stable provider identity.
6. Track created/updated/unchanged/skipped/failed counts.
7. Do not delete local records because one response omits them; use explicit deletion semantics or mark `possibly_missing`.
8. Apply pricing only when base price and currency inputs are valid.
9. Publishing can be automatic for trusted mappings or require review.
10. Alert on repeated failures, schema drift, large price changes or unexpected item counts.
11. Retry transient timeout/429/5xx with exponential backoff and jitter.
12. Do not retry permanent 4xx without correction.
13. Support cancellation and safe resume where feasible.

Endpoints:
- `POST /api/v1/admin/providers/{provider}/sync`
- `POST /api/v1/admin/providers/{provider}/sync` with body `{"mode":"dry_run"}`
- `POST /api/v1/admin/sync-runs/{run}/cancel`
- `POST /api/v1/admin/sync-runs/{run}/retry-failed`
- `GET /api/v1/admin/sync-runs`
- `GET /api/v1/admin/sync-runs/{run}/items`

Each sync item records external ID, normalized resource ID, action, error code, sanitized message, attempt count and timestamps. Never store secrets or unredacted credentials in logs.

## 14. Pricing Engine

### Inputs
- Provider base/cost price and source.
- Source and target currency.
- Global default markup.
- Provider-specific markup.
- Category markup.
- Product/file override.
- Seller-specific override within policy.
- Fixed addition.
- Minimum/maximum price.
- Rounding strategy.
- Optional FX rate source and timestamp.
- Effective date range and priority.

### Deterministic precedence
Recommended default:
1. Approved product/file override.
2. Seller override within bounds.
3. Category rule.
4. Provider rule.
5. Global default.
6. No automatic price if required cost/currency input is missing.

Define whether rules override or stack. Default: one winning percentage rule plus optional fixed addition; never accidentally stack all matching percentages.

### Formula
For cost `C`, percentage `P`, fixed addition `F`:
`calculated = round(C × (1 + P / 100) + F)`

Example: cost 100.00, markup 15%, fixed addition 2.00 → 117.00 before configured rounding.

If currency conversion is required, convert using an approved rate snapshot, then apply markup unless documented policy specifies otherwise. Use integer minor units or decimal-safe arithmetic; never binary floating-point for money.

### Endpoints
- `GET /api/v1/admin/pricing/rules`
- `POST /api/v1/admin/pricing/rules`
- `GET /api/v1/admin/pricing/rules/{rule}`
- `PATCH /api/v1/admin/pricing/rules/{rule}`
- `DELETE /api/v1/admin/pricing/rules/{rule}` (prefer deactivate when historical use exists)
- `POST /api/v1/admin/pricing/preview`
- `POST /api/v1/admin/pricing/recalculate`
- `GET /api/v1/admin/pricing/history`
- Optional seller endpoints: `/api/v1/seller/pricing/overrides`, `/api/v1/seller/pricing/preview`.

### Pricing safety
- Preview shows inputs, winning rule, formula, rounding and output.
- Bulk recalculation requires dry-run, impact summary and confirmation.
- Large changes trigger configured approval.
- Price history records source rule and actor/job.
- Historical order item prices never change.
- Reject negative prices; define zero-cost/free item policy.
- Seller overrides obey bounds and approval rules.
- Missing/untrusted base price prevents automatic pricing.

## 15. REST Conventions

- JSON request/response; `Accept: application/json`.
- Bearer token for scoped API clients.
- Pagination: `page`, `per_page` with a configured maximum.
- Filters/sorts are allowlisted.
- Bulk endpoints enforce item count and request-size limits.
- Require `Idempotency-Key` for non-idempotent operations where retry risk exists.
- Use stable error codes; never expose stack traces, SQL, storage paths or raw provider payloads.

Success envelope:
```json
{
  "data": {
    "id": "0199f6c8-7d21-7a42-9c8f-6fce2a8b4210",
    "code": "GSMWHALE-1A2B-3C4D-5E6F-7A8B",
    "status": "active"
  },
  "meta": {"request_id": "req_01J...", "api_version": "v1"}
}
```

Error envelope:
```json
{
  "error": {
    "code": "validation_failed",
    "message": "The request contains invalid fields.",
    "fields": {"name": ["The name field is required."]}
  },
  "meta": {"request_id": "req_01J...", "api_version": "v1"}
}
```

Suggested status codes: 200, 201, 202, 204, 400, 401, 403, 404, 409, 422, 429, 502, 503 and 504 according to the actual failure.

## 16. Example Requests

### Create folder
`POST /api/v1/seller/folders`
```json
{
  "name": "Samsung Firmware",
  "parent_id": null,
  "description": "Firmware catalog folder",
  "metadata": {"brand": "Samsung"}
}
```

### Create file metadata
`POST /api/v1/seller/files`
```json
{
  "folder_id": "0199f6c8-7d21-7a42-9c8f-6fce2a8b4210",
  "category_id": "0199f6d1-3a10-7e88-8c01-0ccac2a2c111",
  "name": "Example Firmware Package",
  "version": "1.0.0",
  "metadata": {"brand": "Samsung", "device_model": "Example Model", "region": "Global"}
}
```

### Register provider (admin only)
`POST /api/v1/admin/providers`
```json
{
  "name": "Provider One",
  "adapter_key": "provider_one",
  "base_url": "https://api.provider.example/v1",
  "auth_type": "api_key_header",
  "enabled": false,
  "capabilities": ["list_folders", "list_files", "list_categories", "pricing"]
}
```
Credentials are set through a protected secret-setting flow and never returned by GET.

### Dry-run sync
`POST /api/v1/admin/providers/{provider}/sync`
```json
{
  "mode": "dry_run",
  "scope": {"folder_code": "GSMWHALE-1A2B-3C4D-5E6F-7A8B"},
  "options": {
    "include_files": true,
    "include_categories": true,
    "apply_pricing": false,
    "publish": false
  }
}
```
Return `202 Accepted` with sync-run ID/status URL. Dry-run must not publish or change prices.

### Pricing preview
`POST /api/v1/admin/pricing/preview`
```json
{
  "base_price_minor": 10000,
  "currency": "USD",
  "markup_percent": "15.00",
  "fixed_addition_minor": 200,
  "rounding": "minor_unit"
}
```
Illustrative result: 100.00 USD × 1.15 + 2.00 USD = 117.00 USD.

## 17. Database Model

Suggested tables:
- `seller_profiles`
- Sanctum personal access tokens or equivalent scoped token records
- `brands`, `folders`, `files`, `file_versions`, `categories`
- `category_mappings`
- `custom_parameter_schemas`, `custom_parameter_values`
- `providers`, encrypted credential records/secret references
- `provider_mappings`, `provider_sync_runs`, `provider_sync_items`
- `pricing_rules`, `price_history`
- `automation_rules`, `automation_runs`
- `audit_events`

Constraints:
- UUID primary/canonical IDs.
- Unique branded code.
- Unique `(provider_id, external_id)` for provider-sourced resources.
- Foreign keys and ownership indexes.
- Unique idempotency keys scoped by principal/operation.
- Index seller/provider/category/status/timestamp/sync-run fields.
- Use JSON only for validated flexible metadata.
- Encrypt credentials or store external secret references.
- Preserve price history and order snapshots.

## 18. Automation Rule Model

A rule may define name, enabled state, trigger type, schedule/event, provider/folder/category scope, filters, allowlisted operation, validated parameters, dry-run policy, retry/backoff, concurrency, max items, approval requirement, alert destination and last/next run.

Never allow arbitrary code execution as an automation action. Use registered action identifiers and validated parameters only.

## 19. Rate Limits and Quotas

Define separate quotas for:
- Authentication/token creation.
- Reads and writes.
- Bulk sync and connection tests.
- Pricing preview/recalculation.
- Uploads and admin global operations.

Quota dimensions may include principal, seller, token, provider and IP. Return `429` with safe retry guidance. Do not expose another seller's usage data.

## 20. Security and Threat Controls

- Prevent broken object-level authorization/IDOR and cross-seller access.
- Encrypt provider credentials and redact secrets.
- Prevent SSRF through provider URL validation, DNS/redirect controls and allowlists.
- Prevent mass assignment of seller ID, status, price and provider ID.
- Prevent arbitrary adapter/class resolution.
- Validate provider payloads against canonical schemas.
- Prevent duplicate sync runs and duplicate price changes.
- Prevent public disclosure of private storage keys.
- Use CSRF protections on cookie-authenticated browser routes.
- Use token abilities, revocation and rate limits.
- Apply timeouts, backoff and concurrency limits to provider calls.
- Audit actor/action/target/result/request ID without secrets.

## 21. Testing Requirements

### Unit tests
- UUID and branded code generation, normalization and collision retry.
- Pricing formula, rule precedence, rounding, min/max and currency conversion.
- Provider normalization and custom parameter validation.
- Sync conflict resolution and idempotency key generation.

### Feature tests
- Seller can access only owned folders/files/categories.
- Suspended seller cannot write/sync.
- Admin provider routes require permissions.
- Provider GET responses never include secrets.
- Folder hierarchy cannot create cycles.
- Bulk limits/rate limits are enforced.
- Price preview does not persist.
- Recalculation dry-run does not mutate prices.
- Invalid provider URLs are rejected.

### Integration/contract tests
- Provider adapters use fixtures or sandbox.
- Timeout, 429, 5xx, malformed payload and schema drift are handled.
- Duplicate pages do not duplicate records.
- Sync resumes safely from checkpoint.
- Failed items can be retried.
- Logs redact secrets.

### Security tests
- Cross-seller ID substitution.
- SSRF attempts against localhost/private/link-local addresses and redirects.
- Mass assignment of protected fields.
- Secret leakage in logs/errors.
- Unauthorized price overrides.
- Arbitrary adapter-key injection.
- Excessive pagination and oversized bulk requests.

## 22. Acceptance Criteria

- [ ] API is versioned and documented.
- [ ] Seller tokens have explicit abilities and revocation.
- [ ] UUID is canonical; branded code is a unique alternate reference.
- [ ] Folder/file/category CRUD respects ownership.
- [ ] Custom parameters are schema-validated and never executed.
- [ ] Provider adapters normalize data into a canonical model.
- [ ] Provider credentials are protected and never returned.
- [ ] Sync is idempotent, observable and resumable where possible.
- [ ] Pricing preview shows rule and calculation.
- [ ] Bulk repricing supports dry-run, impact summary and approval thresholds.
- [ ] Price history records rule/source and actor/job.
- [ ] Sellers cannot alter global provider settings.
- [ ] SSRF and cross-tenant access tests pass.
- [ ] Critical endpoints have positive and negative tests.
- [ ] OpenAPI docs match actual routes and schemas.

## 23. Implementation Roadmap

### Phase 0 — Discovery
Inventory routes/models/provider contracts; verify installed packages; confirm provider authorization, seller isolation, currency and pricing policy.

### Phase 1 — API foundation
Versioned routes, authentication, error envelopes, rate limits, UUID/code generator, seller policies.

### Phase 2 — Catalog CRUD
Folders, files, categories, parameter schemas, private storage and upload validation.

### Phase 3 — Provider framework
Provider registry, adapter contract, encrypted credentials, SSRF defenses, health check and fixtures.

### Phase 4 — Synchronization
Runs/items, checkpoints, deduplication, retries, dry-run, reports, scheduling and alerts.

### Phase 5 — Pricing engine
Rules, precedence, preview, rounding, price history, bulk dry-run and approval thresholds.

### Phase 6 — Hardening and release
Security review, sandbox tests, OpenAPI verification, rate limits, operations docs and QA sign-off.

## 24. Open Decisions

1. Are providers global admin-managed, seller-managed, or both with separate permissions?
2. Which concrete provider APIs are first priority?
3. Do providers return folders, files, categories, cost price, availability, order status or balance?
4. Is the branded prefix global (`GSMWHALE`) or configurable per seller/brand?
5. Can sellers create categories or only map provider categories to global categories?
6. What are markup limits, fixed additions, rounding and currency rules?
7. Is FX conversion required, and which source is authoritative?
8. Which actions require approval: provider enablement, publish, bulk sync, repricing or seller overrides?
9. What are API quotas and provider concurrency limits?
10. Are provider files references, metadata or copied binaries, and what rights permit copying?
11. How long are sanitized provider payloads and sync logs retained?
12. Which webhook signatures or polling methods do selected providers support?

## 25. Definition of Done

Requirements have validation, authorization, observability and documentation. Database constraints protect uniqueness/idempotency. Provider adapters pass contract tests. Pricing is deterministic and auditable. Cross-seller and SSRF tests pass. No secrets appear in responses/logs/docs. OpenAPI matches actual routes. Staging smoke tests and product/QA/security sign-off are recorded.
